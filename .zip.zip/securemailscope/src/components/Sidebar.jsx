import React from 'react';
import { 
  LayoutDashboard, 
  FileSearch, 
  Eye, 
  Sparkles, 
  ShieldAlert, 
  ListOrdered, 
  Wrench, 
  FileText,
  ChevronLeft,
  ChevronRight,
  Shield,
  Lock,
  MailCheck
} from 'lucide-react';

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'analyzer', label: 'PCAP Analyzer', icon: FileSearch },
  { id: 'discovery', label: 'Discovery', icon: Eye },
  { id: 'ai-analysis', label: 'AI Analysis', icon: Sparkles },
  { id: 'risk-assessment', label: 'Risk Assessment', icon: ShieldAlert, countKey: 'findings' },
  { id: 'prioritized-fixes', label: 'Prioritized Fixes', icon: ListOrdered, countKey: 'findings' },
  { id: 'recommendations', label: 'Recommendations', icon: Wrench },
  { id: 'report', label: 'Report', icon: FileText },
];

export default function Sidebar({ 
  currentTab, 
  onSelectTab, 
  scenario, 
  isCollapsed, 
  onToggleCollapse 
}) {
  const findingsCount = scenario.findings?.length || 0;

  return (
    <aside 
      className={`bg-[#0B0F14] border-r border-[#1F2937] flex flex-col justify-between transition-all duration-200 select-none z-20 no-print ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div>
        <div className="p-4 border-b border-[#1F2937] flex items-center justify-between">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-sky-500/20 shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            {!isCollapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h1 className="text-sm font-bold text-white tracking-tight truncate">
                    SecureMail<span className="text-sky-400">Scope</span>
                  </h1>
                </div>
                <p className="text-[10px] font-mono text-gray-400 truncate">
                  Crypto Posture Assessment
                </p>
              </div>
            )}
          </div>

          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex p-1 rounded-md bg-[#161B22] text-gray-400 hover:text-white border border-[#1F2937] transition-colors"
            title={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Navigation List */}
        <nav className="p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            const count = item.countKey === 'findings' ? findingsCount : null;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all group ${
                  isActive
                    ? 'bg-blue-600/15 text-sky-400 border border-sky-500/30 font-semibold'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-[#161B22] border border-transparent'
                }`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sky-400' : 'text-gray-400 group-hover:text-gray-300'}`} />
                
                {!isCollapsed && (
                  <span className="flex-1 text-left truncate">
                    {item.label}
                  </span>
                )}

                {!isCollapsed && count !== null && count > 0 && (
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-sky-500/20 text-sky-300' : 'bg-gray-800 text-gray-400'
                  }`}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Telemetry Card */}
      <div className="p-3 border-t border-[#1F2937]">
        {!isCollapsed ? (
          <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-mono">
              <span className="text-gray-400">Engine State</span>
              <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                ONLINE
              </span>
            </div>
            <div className="text-[10px] text-gray-500 font-mono">
              Target: <span className="text-gray-300">{scenario.uploadedFile.name}</span>
            </div>
          </div>
        ) : (
          <div className="flex justify-center" title="Engine Status: Online">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        )}
      </div>
    </aside>
  );
}
