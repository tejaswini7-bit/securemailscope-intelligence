import React, { useState, useEffect } from 'react';
import PipelineStepper from './PipelineStepper';
import { PIPELINE_STAGES } from '../data/scenarios';
import { Loader2, Terminal, Shield, CheckCircle2 } from 'lucide-react';

const LOG_MESSAGES = [
  "Initializing PCAP buffer: reading pcap global header (magic: 0xa1b2c3d4)...",
  "Dissecting Layer 2/3 frames: IP checksum validation complete...",
  "Classifying TCP streams: isolated SMTP port 25/587 conversations...",
  "Parsing TLS Record Layer: found ContentType 22 (Handshake) / ClientHello...",
  "Inspecting Certificate payloads: evaluating X.509 DER structure...",
  "Evaluating cipher suite identifier & PRF hash parameters...",
  "Checking Key Exchange parameters: evaluating Ephemeral Diffie-Hellman / PFS...",
  "Scanning payload stream for MIME boundaries & S/MIME application/pkcs7...",
  "Compiling heuristic cryptographic feature vector for posture scoring...",
  "Synthesizing threat model, CIA triad exposure, and remediation priorities..."
];

export default function AnalysisProgress({ scenario, onComplete }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [logs, setLogs] = useState([LOG_MESSAGES[0]]);
  const [percent, setPercent] = useState(10);

  useEffect(() => {
    const totalSteps = 10;
    const stepDuration = 480; // ~4.8 seconds total

    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < totalSteps) {
          const nextStep = prev + 1;
          setPercent(Math.round((nextStep / totalSteps) * 100));
          setLogs((prevLogs) => [LOG_MESSAGES[nextStep - 1], ...prevLogs.slice(0, 5)]);
          return nextStep;
        } else {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 600);
          return prev;
        }
      });
    }, stepDuration);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="space-y-6 max-w-4xl mx-auto py-4">
      {/* Header Banner */}
      <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-6 text-center space-y-3 shadow-lg">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-500/10 border border-sky-500/30 text-sky-400">
          <Loader2 className="w-6 h-6 animate-spin" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white font-mono">
            Executing 10-Stage Cryptographic Dissection Pipeline
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Analyzing <span className="font-mono text-sky-300 font-semibold">{scenario.uploadedFile.name}</span> ({scenario.uploadedFile.packetCount.toLocaleString()} frames)
          </p>
        </div>

        {/* Global Progress Bar */}
        <div className="w-full max-w-lg mx-auto space-y-1.5 pt-2">
          <div className="flex justify-between text-xs font-mono text-gray-400">
            <span>Pipeline Progress</span>
            <span className="text-sky-400 font-bold">{percent}%</span>
          </div>
          <div className="w-full bg-[#0B0F14] h-2.5 rounded-full overflow-hidden border border-[#1F2937]">
            <div 
              className="h-full bg-gradient-to-r from-blue-600 via-sky-400 to-emerald-400 transition-all duration-300 ease-out rounded-full"
              style={{ width: `${percent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Live Dissection Stepper */}
      <PipelineStepper currentStep={currentStep} mode="detailed" />

      {/* Simulated Live Console Log */}
      <div className="bg-[#0B0F14] border border-[#1F2937] rounded-xl p-4 font-mono shadow-inner">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#1F2937] text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-sky-400" />
            <span className="font-semibold text-gray-300">Live Dissection Console Stream</span>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
            REALTIME DECODER
          </span>
        </div>

        <div className="space-y-1 text-[11px] min-h-[110px]">
          {logs.map((log, index) => (
            <div 
              key={index} 
              className={`flex items-start gap-2 ${
                index === 0 ? 'text-sky-300 font-semibold' : 'text-gray-500'
              }`}
            >
              <span className="text-gray-600 select-none">&gt;&gt;</span>
              <span>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
