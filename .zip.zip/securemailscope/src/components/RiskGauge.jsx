import React from 'react';

export default function RiskGauge({ score = 0, band = 'LOW RISK', size = 220 }) {
  // Determine color theme based on score
  let color = '#16A34A'; // Green
  let glowColor = 'rgba(22, 163, 74, 0.25)';
  let bandLabel = band;

  if (score < 40) {
    color = '#DC2626'; // Critical Red
    glowColor = 'rgba(220, 38, 38, 0.3)';
  } else if (score < 70) {
    color = '#D97706'; // Amber
    glowColor = 'rgba(217, 119, 6, 0.25)';
  } else if (score < 85) {
    color = '#38BDF8'; // Sky Blue
    glowColor = 'rgba(56, 189, 248, 0.25)';
  }

  // Semi-circle gauge calculations (180 degrees)
  const radius = 80;
  const strokeWidth = 14;
  const normalizedRadius = radius - strokeWidth / 2;
  const circumference = normalizedRadius * Math.PI; // Half circle
  const strokeDashoffset = circumference - (Math.min(100, Math.max(0, score)) / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center relative select-none">
      <div className="relative" style={{ width: size, height: size * 0.65 }}>
        <svg
          viewBox="0 0 200 120"
          className="w-full h-full overflow-visible"
        >
          <defs>
            {/* Background track gradient */}
            <linearGradient id="gaugeTrack" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#1F2937" />
              <stop offset="100%" stopColor="#1F2937" />
            </linearGradient>
            
            {/* Active score gradient */}
            <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={score < 50 ? '#DC2626' : '#EA580C'} />
              <stop offset="50%" stopColor={score < 50 ? '#EA580C' : '#D97706'} />
              <stop offset="100%" stopColor={color} />
            </linearGradient>

            <filter id="gaugeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor={color} floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Background Track Arc */}
          <path
            d="M 20 105 A 80 80 0 0 1 180 105"
            fill="none"
            stroke="#1F2937"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />

          {/* Score Range Ticks */}
          <circle cx="20" cy="105" r="3" fill="#6B7280" />
          <circle cx="100" cy="25" r="3" fill="#6B7280" />
          <circle cx="180" cy="105" r="3" fill="#6B7280" />

          {/* Active Score Arc */}
          <path
            d="M 20 105 A 80 80 0 0 1 180 105"
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            filter="url(#gaugeGlow)"
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center Score Readout */}
        <div className="absolute inset-x-0 bottom-0 flex flex-col items-center justify-center">
          <div className="flex items-baseline gap-1">
            <span 
              className="text-4xl font-extrabold tracking-tight font-mono"
              style={{ color }}
            >
              {score}
            </span>
            <span className="text-gray-500 font-mono text-sm font-semibold">/100</span>
          </div>
        </div>
      </div>

      {/* Risk Band Badge */}
      <div className="mt-2 flex flex-col items-center">
        <span 
          className="px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider uppercase border"
          style={{ 
            color, 
            borderColor: `${color}40`,
            backgroundColor: `${color}15`,
            boxShadow: `0 0 12px ${glowColor}`
          }}
        >
          {bandLabel}
        </span>
        <span className="text-[11px] text-gray-400 mt-1 font-mono">
          Cryptographic Posture Index
        </span>
      </div>
    </div>
  );
}
