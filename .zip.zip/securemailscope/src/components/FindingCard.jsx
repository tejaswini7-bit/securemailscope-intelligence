import React, { useState } from 'react';
import SeverityBadge from './SeverityBadge';
import ObservabilityPill from './ObservabilityPill';
import { 
  ChevronDown, 
  ChevronUp, 
  AlertCircle, 
  ShieldAlert, 
  Sparkles, 
  Wrench, 
  Calculator, 
  Check, 
  Copy,
  Tag
} from 'lucide-react';
import { calculatePriorityScore } from '../utils/scoring';

export default function FindingCard({ finding, showPriorityRank = true, defaultExpanded = false }) {
  const [expanded, setExpanded] = useState(defaultExpanded);
  const [copied, setCopied] = useState(false);
  const [showFormula, setShowFormula] = useState(false);

  const handleCopyFix = (e) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(finding.recommendedFix);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const priorityScore = calculatePriorityScore(finding.priorityScoreBreakdown);

  return (
    <div className="bg-[#161B22] border border-[#1F2937] hover:border-gray-700 rounded-xl overflow-hidden shadow-sm transition-all duration-150">
      {/* Card Header / Summary Row */}
      <div 
        onClick={() => setExpanded(!expanded)}
        className="p-4 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none"
      >
        <div className="flex items-start sm:items-center gap-3">
          {showPriorityRank && (
            <div className="w-7 h-7 rounded-lg bg-[#111827] border border-[#1F2937] flex items-center justify-center font-mono font-bold text-xs text-sky-400 shrink-0">
              #{finding.priorityRank}
            </div>
          )}

          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <SeverityBadge severity={finding.severity} size="xs" />
              <ObservabilityPill status={finding.observability} size="xs" />
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-gray-800 text-gray-400 uppercase tracking-wider">
                {finding.category}
              </span>
            </div>

            <h4 className="text-sm font-semibold text-gray-100 leading-snug">
              {finding.title}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-3 self-end sm:self-center">
          <div className="text-right hidden md:block">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">
              Priority Formula Score
            </span>
            <span className="font-mono text-xs font-bold text-sky-300">
              {priorityScore} pts
            </span>
          </div>

          <button 
            type="button"
            className="p-1 rounded bg-[#111827] border border-[#1F2937] text-gray-400 hover:text-white transition-colors"
          >
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expandable Body */}
      {expanded && (
        <div className="px-4 pb-4 pt-1 border-t border-[#1F2937]/70 space-y-3.5 text-xs text-gray-300">
          {/* Detected string */}
          <div className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#1F2937] font-mono">
            <span className="text-gray-500 font-semibold block text-[10px] uppercase mb-0.5">
              Detected Artifact (Frame Evidence)
            </span>
            <code className="text-sky-300 break-all text-[11px]">
              {finding.detected}
            </code>
          </div>

          {/* Why Dangerous */}
          <div>
            <span className="font-semibold text-gray-200 flex items-center gap-1.5 mb-1">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              Why This Is Dangerous
            </span>
            <p className="text-gray-300 leading-relaxed pl-5 text-[11px]">
              {finding.whyDangerous}
            </p>
          </div>

          {/* Impact Tags */}
          {finding.impact && finding.impact.length > 0 && (
            <div>
              <span className="font-semibold text-gray-400 text-[11px] block mb-1">
                Potential Security Impact:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {finding.impact.map((tag, i) => (
                  <span 
                    key={i} 
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-red-950/40 border border-red-800/40 text-red-300 text-[10px] font-mono"
                  >
                    <Tag className="w-2.5 h-2.5" />
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Recommended Fix */}
          <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-500/30">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-semibold text-emerald-400 flex items-center gap-1.5 text-xs">
                <Wrench className="w-3.5 h-3.5" />
                Recommended Remediation Action
              </span>
              <button
                onClick={handleCopyFix}
                className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy Action'}</span>
              </button>
            </div>
            <p className="text-gray-200 text-[11px] leading-relaxed">
              {finding.recommendedFix}
            </p>
          </div>

          {/* AI Narrative Integration */}
          {finding.aiNarrative && (
            <div className="p-3 rounded-lg bg-blue-950/20 border-l-2 border-sky-500 border-y border-r border-[#1F2937]">
              <div className="flex items-center gap-1.5 text-sky-400 text-[11px] font-semibold mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Heuristic Reasoning Note</span>
              </div>
              <p className="text-gray-300 text-[11px] leading-relaxed">
                {finding.aiNarrative}
              </p>
            </div>
          )}

          {/* Transparent Formula Drawer Toggle */}
          {finding.priorityScoreBreakdown && (
            <div className="pt-2 border-t border-[#1F2937]/50">
              <button
                type="button"
                onClick={() => setShowFormula(!showFormula)}
                className="flex items-center gap-1.5 text-[11px] font-mono text-gray-400 hover:text-sky-400 transition-colors"
              >
                <Calculator className="w-3 h-3" />
                <span>{showFormula ? 'Hide priority formula parameters' : 'Inspect deterministic ranking formula'}</span>
              </button>

              {showFormula && (
                <div className="mt-2 p-2.5 rounded-lg bg-[#0B0F14] border border-[#1F2937] text-[11px] font-mono space-y-1.5">
                  <div className="text-gray-400">
                    Formula: <span className="text-sky-300 font-bold">(Severity × 4) + (Exploitability × 3) + (Exposure × 3) + (Deprecated ? 15 : 0)</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-gray-300">
                    <div>Severity: <span className="text-white font-bold">{finding.priorityScoreBreakdown.severity}/10</span></div>
                    <div>Exploitability: <span className="text-white font-bold">{finding.priorityScoreBreakdown.exploitability}/10</span></div>
                    <div>Exposure: <span className="text-white font-bold">{finding.priorityScoreBreakdown.exposure}/10</span></div>
                    <div>Deprecated Alg: <span className="text-white font-bold">{finding.priorityScoreBreakdown.deprecated ? 'YES (+15)' : 'NO (0)'}</span></div>
                  </div>
                  <div className="text-gray-400 text-[10px]">
                    Impacted CIA Dimensions: <span className="text-emerald-400">{finding.priorityScoreBreakdown.cia?.join(', ') || 'N/A'}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
