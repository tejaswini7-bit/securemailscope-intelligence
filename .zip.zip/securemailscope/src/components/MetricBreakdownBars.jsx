import React from 'react';
import ObservabilityPill from './ObservabilityPill';
import { Shield, Key, FileCheck, Mail, Lock } from 'lucide-react';

export default function MetricBreakdownBars({ breakdown = {} }) {
  const metrics = [
    {
      key: 'tlsSecurity',
      name: 'TLS Protocol Security',
      value: breakdown.tlsSecurity,
      icon: Shield,
      desc: 'Handshake protocol version & downgrade protection'
    },
    {
      key: 'algorithmStrength',
      name: 'Algorithm & Cipher Strength',
      value: breakdown.algorithmStrength,
      icon: Lock,
      desc: 'AEAD vs CBC mode, PRF digest integrity'
    },
    {
      key: 'keySecurity',
      name: 'Key Exchange & PFS Security',
      value: breakdown.keySecurity,
      icon: Key,
      desc: 'Ephemeral DH curves vs static key exchange'
    },
    {
      key: 'certificateSecurity',
      name: 'Certificate & Chain Security',
      value: breakdown.certificateSecurity,
      icon: FileCheck,
      desc: 'Public key size, CA chain, signature collision resistance'
    },
    {
      key: 'emailEncryption',
      name: 'Email Transport / S-MIME',
      value: breakdown.emailEncryption,
      icon: Mail,
      desc: 'STARTTLS enforcement & payload encryption'
    }
  ];

  const getBarColor = (val) => {
    if (val >= 80) return 'bg-emerald-500';
    if (val >= 60) return 'bg-amber-500';
    if (val >= 40) return 'bg-orange-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-4">
      {metrics.map((metric) => {
        const IconComponent = metric.icon;
        const isObservable = metric.value !== null && metric.value !== undefined;

        return (
          <div 
            key={metric.key} 
            className={`p-3 rounded-lg border transition-colors ${
              isObservable 
                ? 'bg-[#161B22]/70 border-[#1F2937]' 
                : 'bg-[#111827]/40 border-dashed border-gray-800'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5 gap-2">
              <div className="flex items-center gap-2">
                <span className={`p-1.5 rounded ${isObservable ? 'bg-blue-500/10 text-sky-400' : 'bg-gray-800 text-gray-500'}`}>
                  <IconComponent className="w-3.5 h-3.5" />
                </span>
                <div>
                  <span className={`text-xs font-semibold ${isObservable ? 'text-gray-200' : 'text-gray-400'}`}>
                    {metric.name}
                  </span>
                  <p className="text-[10px] text-gray-500 hidden sm:block">
                    {metric.desc}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {isObservable ? (
                  <div className="text-right">
                    <span className="font-mono text-sm font-bold text-white">
                      {metric.value}%
                    </span>
                  </div>
                ) : (
                  <ObservabilityPill 
                    status="not_observable" 
                    note="Encrypted by TLS 1.3 protocol handshake or withheld from passive PCAP" 
                    size="xs" 
                  />
                )}
              </div>
            </div>

            {/* Progress track */}
            <div className="w-full bg-[#0B0F14] h-2 rounded-full overflow-hidden border border-[#1F2937]/50">
              {isObservable ? (
                <div 
                  className={`h-full rounded-full transition-all duration-700 ease-out ${getBarColor(metric.value)}`}
                  style={{ width: `${metric.value}%` }}
                />
              ) : (
                <div className="h-full w-full bg-repeating-linear-gradient flex items-center justify-center">
                  <div className="w-full h-full bg-gray-800/60" />
                </div>
              )}
            </div>

            {!isObservable && (
              <div className="mt-1 text-[11px] text-gray-400 font-mono italic flex items-center gap-1.5">
                <span>Not scored (not observable from PCAP)</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
