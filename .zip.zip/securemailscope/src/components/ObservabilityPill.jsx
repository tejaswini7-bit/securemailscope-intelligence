import React, { useState } from 'react';
import { getObservabilityDetails } from '../utils/scoring';

export default function ObservabilityPill({ status, note, size = 'sm', showTooltip = true }) {
  const [hovered, setHovered] = useState(false);
  const details = getObservabilityDetails(status);

  const sizeClasses = size === 'xs' 
    ? 'text-[11px] px-2 py-0.5' 
    : 'text-xs px-2.5 py-1';

  return (
    <div 
      className="relative inline-flex items-center"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <span className={`inline-flex items-center gap-1.5 font-mono font-medium rounded-full border ${details.bgColor} ${details.borderColor} ${details.textColor} ${sizeClasses} shadow-sm transition-colors duration-150`}>
        <span className="text-[9px] leading-none">{details.symbol}</span>
        <span>{details.tag}</span>
      </span>

      {showTooltip && hovered && (
        <div className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-2.5 rounded-lg bg-[#161B22] border border-[#1F2937] text-gray-200 text-xs shadow-xl pointer-events-none animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center gap-1.5 font-semibold text-white mb-1">
            <span>{details.symbol}</span>
            <span>{details.tag}</span>
          </div>
          <p className="text-gray-400 text-[11px] leading-relaxed mb-1">
            {details.description}
          </p>
          {note && (
            <div className="mt-1.5 pt-1.5 border-t border-[#1F2937] text-[11px] text-sky-300 font-mono">
              <span className="font-semibold text-gray-300">Analysis note: </span>{note}
            </div>
          )}
          <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-[#161B22]" />
        </div>
      )}
    </div>
  );
}
