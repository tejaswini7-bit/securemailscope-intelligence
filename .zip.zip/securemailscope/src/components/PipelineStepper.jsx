import React from 'react';
import { PIPELINE_STAGES } from '../data/scenarios';
import { CheckCircle2, Loader2, Circle, ArrowRight } from 'lucide-react';

export default function PipelineStepper({ 
  currentStep = 10, 
  mode = 'compact', // 'compact' | 'detailed'
  completed = false
}) {
  if (mode === 'compact') {
    return (
      <div className="w-full bg-[#111827] border border-[#1F2937] rounded-xl p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-300">
              Cryptographic Ingestion & Analysis Pipeline (10 Stages)
            </h4>
          </div>
          <span className="text-[11px] font-mono text-gray-500">
            Stages 1–10 Dissection Flow
          </span>
        </div>

        {/* Stepper track */}
        <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
          {PIPELINE_STAGES.map((stage) => {
            const isDone = completed || stage.id <= currentStep;
            const isCurrent = stage.id === currentStep && !completed;

            return (
              <div 
                key={stage.id}
                className={`relative p-2 rounded-lg border text-left transition-all ${
                  isCurrent
                    ? 'bg-blue-500/10 border-blue-500 text-sky-300'
                    : isDone
                    ? 'bg-[#161B22] border-emerald-500/40 text-gray-200'
                    : 'bg-[#161B22]/40 border-gray-800 text-gray-500'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                    isCurrent ? 'bg-sky-500 text-black' : isDone ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-800 text-gray-500'
                  }`}>
                    0{stage.id}
                  </span>
                  {isCurrent ? (
                    <Loader2 className="w-3 h-3 text-sky-400 animate-spin" />
                  ) : isDone ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Circle className="w-3 h-3 text-gray-700" />
                  )}
                </div>
                <div className="text-[11px] font-medium truncate" title={stage.title}>
                  {stage.title}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Detailed mode for active PCAP analyzer
  return (
    <div className="w-full space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
        {PIPELINE_STAGES.map((stage) => {
          const isDone = completed || stage.id < currentStep;
          const isCurrent = stage.id === currentStep && !completed;
          const isPending = stage.id > currentStep;

          return (
            <div 
              key={stage.id}
              className={`p-3.5 rounded-lg border transition-all duration-300 flex items-start gap-3 ${
                isCurrent 
                  ? 'bg-blue-950/40 border-sky-500 shadow-md shadow-sky-950/40' 
                  : isDone 
                  ? 'bg-[#161B22] border-emerald-500/30' 
                  : 'bg-[#111827]/40 border-gray-800 opacity-50'
              }`}
            >
              <div className="mt-0.5">
                {isCurrent ? (
                  <div className="w-6 h-6 rounded-full bg-blue-500/20 border border-sky-400 flex items-center justify-center">
                    <Loader2 className="w-3.5 h-3.5 text-sky-400 animate-spin" />
                  </div>
                ) : isDone ? (
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500 flex items-center justify-center">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                ) : (
                  <div className="w-6 h-6 rounded-full bg-gray-800 border border-gray-700 flex items-center justify-center text-[11px] font-mono text-gray-400">
                    {stage.id}
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h5 className={`text-xs font-semibold font-mono ${
                    isCurrent ? 'text-sky-300' : isDone ? 'text-gray-200' : 'text-gray-500'
                  }`}>
                    Stage {stage.id}: {stage.title}
                  </h5>
                  <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                    isCurrent ? 'bg-sky-500/20 text-sky-300' : isDone ? 'bg-emerald-500/10 text-emerald-400' : 'text-gray-600'
                  }`}>
                    {isCurrent ? 'Processing...' : isDone ? 'Completed' : 'Queued'}
                  </span>
                </div>
                <p className="text-[11px] text-gray-400 mt-0.5 leading-snug">
                  {stage.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
