import React from 'react';
import { AlertTriangle, AlertCircle, AlertOctagon, ShieldCheck, Info } from 'lucide-react';
import { getSeverityDetails } from '../utils/scoring';

export default function SeverityBadge({ severity, size = 'sm', showIcon = true }) {
  const details = getSeverityDetails(severity);

  const renderIcon = () => {
    switch (details.label) {
      case 'CRITICAL':
        return <AlertTriangle className="w-3 h-3" />;
      case 'HIGH':
        return <AlertCircle className="w-3 h-3" />;
      case 'MEDIUM':
        return <AlertOctagon className="w-3 h-3" />;
      case 'LOW':
        return <ShieldCheck className="w-3 h-3" />;
      default:
        return <Info className="w-3 h-3" />;
    }
  };

  const sizeClasses = size === 'xs'
    ? 'text-[10px] px-2 py-0.5 tracking-wider'
    : size === 'lg'
    ? 'text-xs px-3 py-1.5 tracking-wider'
    : 'text-[11px] px-2.5 py-0.5 tracking-wider';

  return (
    <span className={`inline-flex items-center gap-1.5 font-mono font-bold rounded border uppercase ${details.badgeBg} ${details.badgeBorder} ${details.textColor} ${sizeClasses}`}>
      {showIcon && renderIcon()}
      <span>{details.label}</span>
    </span>
  );
}
