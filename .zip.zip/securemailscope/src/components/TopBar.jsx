import React from 'react';
import { SCENARIOS } from '../data/scenarios';
import { ShieldCheck, AlertTriangle, ChevronDown, Radio, Activity, Cpu } from 'lucide-react';

export default function TopBar({ currentScenarioId, onSelectScenario, onToggleSidebar, isSidebarCollapsed }) {
  const currentScenario = SCENARIOS.find(s => s.id === currentScenarioId) || SCENARIOS[0];

  return (
    <header className="sticky top-0 z-30 bg-[#0B0F14]/95 backdrop-blur-md border-b border-[#1F2937] no-print">
      {/* Persistent Synthetic Data Disclosure Banner */}
      <div className="bg-[#111827] border-b border-[#1F2937] px-4 py-1.5 flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-mono text-[11px] text-gray-300">
            <strong className="text-white font-semibold">Synthetic demonstration dataset</strong> — no real organizational or personal email data is used.
          </span>
        </div>

        <div className="hidden sm:flex items-center gap-3 font-mono text-[11px] text-gray-500">
          <span className="flex items-center gap-1">
            <Cpu className="w-3 h-3 text-sky-400" />
            Heuristic Dissection Engine v2.4
          </span>
          <span>•</span>
          <span className="text-emerald-400">SIH 2024 Finalist Build</span>
        </div>
      </div>

      {/* Main Top Navigation Row */}
      <div className="px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-1.5 rounded-lg bg-[#161B22] border border-[#1F2937] text-gray-400 hover:text-white lg:hidden"
            title="Toggle Sidebar"
          >
            <Activity className="w-4 h-4 text-sky-400" />
          </button>

          <div className="hidden md:flex items-center gap-2 text-xs">
            <span className="text-gray-500 font-mono">WORKSPACE:</span>
            <span className="font-mono font-semibold text-gray-200 bg-[#161B22] px-2.5 py-1 rounded border border-[#1F2937]">
              MTA Cryptographic Assessment
            </span>
          </div>
        </div>

        {/* Scenario Switcher Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <label className="text-xs font-mono text-gray-400 hidden sm:inline">
              Active Scenario:
            </label>
            <div className="relative">
              <select
                value={currentScenarioId}
                onChange={(e) => onSelectScenario(e.target.value)}
                className="appearance-none bg-[#161B22] border border-[#1F2937] hover:border-sky-500/50 text-xs font-mono text-gray-200 rounded-lg px-3 py-2 pr-8 focus:outline-none focus:ring-1 focus:ring-sky-500 cursor-pointer shadow-sm"
              >
                {SCENARIOS.map((s) => (
                  <option key={s.id} value={s.id} className="bg-[#161B22] text-white">
                    {s.name} ({s.riskScore.band})
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Quick Score indicator */}
          <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-[#1F2937]">
            <span className="text-[11px] font-mono text-gray-500 uppercase">Posture:</span>
            <span 
              className="text-xs font-mono font-bold px-2 py-0.5 rounded border"
              style={{
                color: currentScenario.riskScore.statusColor,
                borderColor: `${currentScenario.riskScore.statusColor}40`,
                backgroundColor: `${currentScenario.riskScore.statusColor}15`
              }}
            >
              {currentScenario.riskScore.overall}/100 • {currentScenario.riskScore.band}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
