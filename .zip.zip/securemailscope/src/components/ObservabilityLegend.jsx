import React from 'react';
import { Info, HelpCircle } from 'lucide-react';
import ObservabilityPill from './ObservabilityPill';

export default function ObservabilityLegend({ className = '' }) {
  return (
    <div className={`bg-[#111827]/90 border border-[#1F2937] rounded-lg px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-sm ${className}`}>
      <div className="flex items-center gap-2">
        <span className="flex items-center justify-center w-5 h-5 rounded bg-blue-500/10 text-sky-400">
          <Info className="w-3.5 h-3.5" />
        </span>
        <span className="text-xs font-semibold text-gray-300 tracking-wide uppercase">
          Observability Standard:
        </span>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <ObservabilityPill status="observed" showTooltip={false} size="xs" />
          <span className="text-[11px] text-gray-400 hidden sm:inline">Directly extracted from PCAP</span>
        </div>

        <div className="h-3 w-px bg-gray-800 hidden sm:block" />

        <div className="flex items-center gap-2">
          <ObservabilityPill status="inferred" showTooltip={false} size="xs" />
          <span className="text-[11px] text-gray-400 hidden sm:inline">Reasoned from protocol parameters</span>
        </div>

        <div className="h-3 w-px bg-gray-800 hidden sm:block" />

        <div className="flex items-center gap-2">
          <ObservabilityPill status="not_observable" showTooltip={false} size="xs" />
          <span className="text-[11px] text-gray-400 hidden sm:inline">Encrypted / withheld by design</span>
        </div>
      </div>
    </div>
  );
}
