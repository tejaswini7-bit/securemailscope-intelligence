import React, { useState, useRef } from 'react';
import { UploadCloud, FileCode, CheckCircle, AlertTriangle, ArrowRight, ShieldCheck } from 'lucide-react';

export default function UploadDropzone({ scenario, onStartAnalysis }) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

  const fileData = scenario.uploadedFile;

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setSelectedFile(e.dataTransfer.files[0].name);
    } else {
      setSelectedFile(fileData.name);
    }
  };

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0].name);
    } else {
      setSelectedFile(fileData.name);
    }
  };

  const triggerUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="space-y-6">
      {/* Drag and Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={triggerUpload}
        className={`border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-200 relative overflow-hidden ${
          dragOver 
            ? 'border-sky-400 bg-sky-950/20 shadow-lg shadow-sky-950/50' 
            : 'border-[#1F2937] bg-[#111827]/70 hover:border-gray-600 hover:bg-[#161B22]'
        }`}
      >
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileSelect} 
          accept=".pcap,.pcapng,.cap" 
          className="hidden" 
        />

        <div className="flex flex-col items-center justify-center space-y-4">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-transform duration-200 ${
            dragOver ? 'scale-110 bg-sky-500/20 border-sky-400 text-sky-300' : 'bg-[#161B22] border-[#1F2937] text-sky-400'
          }`}>
            <UploadCloud className="w-8 h-8" />
          </div>

          <div>
            <h3 className="text-base font-semibold text-gray-100 mb-1">
              Select or Drop PCAP / PCAPNG Network Capture
            </h3>
            <p className="text-xs text-gray-400 max-w-md mx-auto">
              Drag email network trace file here or click to browse. Inspects SMTP, IMAP, and POP3 cryptographic handshakes.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              className="px-4 py-2 rounded-lg bg-[#161B22] hover:bg-gray-800 border border-[#1F2937] text-xs font-mono font-semibold text-gray-200 shadow-sm transition-colors"
            >
              Choose PCAP File
            </button>
            <span className="text-xs text-gray-500 font-mono">or test current scenario file</span>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-mono text-gray-500">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
            <span>Supported formats: .pcap, .pcapng, .cap (Wireshark / tcpdump)</span>
          </div>
        </div>
      </div>

      {/* Selected File Metadata Card */}
      <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#1F2937]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-sky-400">
              <FileCode className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold font-mono text-white">
                  {selectedFile || fileData.name}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-bold">
                  READY FOR INGESTION
                </span>
              </div>
              <p className="text-xs text-gray-400">
                Mapped to active scenario: <strong className="text-gray-200">{scenario.name}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onStartAnalysis}
            className="inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-black font-semibold text-xs tracking-wide shadow-md shadow-sky-500/20 transition-all font-mono self-start sm:self-auto"
          >
            <span>Analyze PCAP</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Metadata Details Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4">
          <div className="bg-[#0B0F14] p-3 rounded-lg border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">
              Capture Size
            </span>
            <span className="text-sm font-mono font-bold text-gray-200">
              {fileData.sizeKB} KB
            </span>
          </div>

          <div className="bg-[#0B0F14] p-3 rounded-lg border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">
              Total Packet Frames
            </span>
            <span className="text-sm font-mono font-bold text-sky-400">
              {fileData.packetCount.toLocaleString()} pkts
            </span>
          </div>

          <div className="bg-[#0B0F14] p-3 rounded-lg border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">
              Capture Duration
            </span>
            <span className="text-sm font-mono font-bold text-gray-200">
              {fileData.durationSec} seconds
            </span>
          </div>

          <div className="bg-[#0B0F14] p-3 rounded-lg border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">
              Detected Protocols
            </span>
            <span className="text-xs font-mono font-semibold text-emerald-400 truncate block" title={fileData.protocolsDetected.join(', ')}>
              {fileData.protocolsDetected.join(', ')}
            </span>
          </div>
        </div>

        {/* Synthetic Notice */}
        <div className="mt-4 pt-3 border-t border-[#1F2937]/50 flex items-center gap-2 text-[11px] text-gray-400">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>
            Synthetic demonstration environment: Analysis engine reads telemetry parameters deterministically from precomputed mock frames.
          </span>
        </div>
      </div>
    </div>
  );
}
