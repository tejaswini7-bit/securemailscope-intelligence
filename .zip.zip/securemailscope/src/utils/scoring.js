/**
 * Scoring and calculation utilities for SecureMailScope
 */

export function getSeverityDetails(severity) {
  switch (severity?.toLowerCase()) {
    case 'critical':
      return {
        label: 'CRITICAL',
        color: '#DC2626',
        bgColor: 'bg-red-950/60',
        borderColor: 'border-red-600/40',
        textColor: 'text-red-400',
        badgeBg: 'bg-red-500/10',
        badgeBorder: 'border-red-500/30',
        dotColor: 'bg-red-500',
        icon: 'AlertTriangle'
      };
    case 'high':
      return {
        label: 'HIGH',
        color: '#EA580C',
        bgColor: 'bg-orange-950/60',
        borderColor: 'border-orange-600/40',
        textColor: 'text-orange-400',
        badgeBg: 'bg-orange-500/10',
        badgeBorder: 'border-orange-500/30',
        dotColor: 'bg-orange-500',
        icon: 'AlertCircle'
      };
    case 'medium':
      return {
        label: 'MEDIUM',
        color: '#D97706',
        bgColor: 'bg-amber-950/60',
        borderColor: 'border-amber-600/40',
        textColor: 'text-amber-400',
        badgeBg: 'bg-amber-500/10',
        badgeBorder: 'border-amber-500/30',
        dotColor: 'bg-amber-500',
        icon: 'AlertOctagon'
      };
    case 'low':
      return {
        label: 'LOW',
        color: '#16A34A',
        bgColor: 'bg-emerald-950/60',
        borderColor: 'border-emerald-600/40',
        textColor: 'text-emerald-400',
        badgeBg: 'bg-emerald-500/10',
        badgeBorder: 'border-emerald-500/30',
        dotColor: 'bg-emerald-500',
        icon: 'ShieldCheck'
      };
    default:
      return {
        label: 'INFO',
        color: '#6B7280',
        bgColor: 'bg-gray-900/60',
        borderColor: 'border-gray-700/40',
        textColor: 'text-gray-400',
        badgeBg: 'bg-gray-500/10',
        badgeBorder: 'border-gray-500/30',
        dotColor: 'bg-gray-400',
        icon: 'Info'
      };
  }
}

export function getObservabilityDetails(status) {
  switch (status) {
    case 'observed':
      return {
        tag: 'Observed',
        symbol: '🟢',
        color: '#10B981',
        bgColor: 'bg-emerald-950/60',
        textColor: 'text-emerald-400',
        borderColor: 'border-emerald-500/30',
        description: 'Directly extracted from PCAP packet payloads or handshake headers.'
      };
    case 'inferred':
      return {
        tag: 'Inferred',
        symbol: '🟡',
        color: '#F59E0B',
        bgColor: 'bg-amber-950/60',
        textColor: 'text-amber-400',
        borderColor: 'border-amber-500/30',
        description: 'Derived cryptographically from observed protocol parameters or standard RFC definitions.'
      };
    case 'not_observable':
    default:
      return {
        tag: 'Not observable from PCAP',
        symbol: '⚪',
        color: '#6B7280',
        bgColor: 'bg-gray-900/60',
        textColor: 'text-gray-400',
        borderColor: 'border-gray-700/40',
        description: 'Payload or metadata is encrypted or withheld by protocol design (e.g. TLS 1.3 encrypted handshake).'
      };
  }
}

/**
 * Deterministic Priority Score Formula:
 * Rank score = (Severity * 4) + (Exploitability * 3) + (Exposure * 3) + (Deprecated ? 15 : 0)
 */
export function calculatePriorityScore(breakdown) {
  if (!breakdown) return 0;
  const { severity = 0, exploitability = 0, exposure = 0, deprecated = false } = breakdown;
  return (severity * 4) + (exploitability * 3) + (exposure * 3) + (deprecated ? 15 : 0);
}
