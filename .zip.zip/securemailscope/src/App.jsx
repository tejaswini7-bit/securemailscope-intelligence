import React, { useState } from 'react';
import { SCENARIOS } from './data/scenarios';
import TopBar from './components/TopBar';
import Sidebar from './components/Sidebar';

// Pages
import Dashboard from './pages/Dashboard';
import PcapAnalyzer from './pages/PcapAnalyzer';
import Discovery from './pages/Discovery';
import AiAnalysis from './pages/AiAnalysis';
import RiskAssessment from './pages/RiskAssessment';
import PrioritizedFixes from './pages/PrioritizedFixes';
import Recommendations from './pages/Recommendations';
import Report from './pages/Report';

export default function App() {
  const [currentScenarioId, setCurrentScenarioId] = useState('scenario_a');
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const scenario = SCENARIOS.find(s => s.id === currentScenarioId) || SCENARIOS[0];

  const handleSelectTab = (tabId) => {
    setCurrentTab(tabId);
    setIsMobileSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderActiveView = () => {
    switch (currentTab) {
      case 'dashboard':
        return <Dashboard scenario={scenario} onNavigate={handleSelectTab} />;
      case 'analyzer':
        return <PcapAnalyzer scenario={scenario} onNavigate={handleSelectTab} />;
      case 'discovery':
        return <Discovery scenario={scenario} />;
      case 'ai-analysis':
        return <AiAnalysis scenario={scenario} />;
      case 'risk-assessment':
        return <RiskAssessment scenario={scenario} />;
      case 'prioritized-fixes':
        return <PrioritizedFixes scenario={scenario} />;
      case 'recommendations':
        return <Recommendations scenario={scenario} />;
      case 'report':
        return <Report scenario={scenario} />;
      default:
        return <Dashboard scenario={scenario} onNavigate={handleSelectTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F14] text-gray-100 flex flex-col selection:bg-sky-500 selection:text-black">
      {/* Top Navigation Bar with persistent banner & scenario selector */}
      <TopBar
        currentScenarioId={currentScenarioId}
        onSelectScenario={setCurrentScenarioId}
        onToggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        isSidebarCollapsed={isSidebarCollapsed}
      />

      {/* Main Container */}
      <div className="flex-1 flex relative overflow-hidden">
        {/* Desktop Sidebar */}
        <div className="hidden lg:flex shrink-0">
          <Sidebar
            currentTab={currentTab}
            onSelectTab={handleSelectTab}
            scenario={scenario}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          />
        </div>

        {/* Mobile Sidebar Overlay */}
        {isMobileSidebarOpen && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            <div 
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              onClick={() => setIsMobileSidebarOpen(false)}
            />
            <div className="relative flex-1 max-w-xs w-full">
              <Sidebar
                currentTab={currentTab}
                onSelectTab={handleSelectTab}
                scenario={scenario}
                isCollapsed={false}
                onToggleCollapse={() => setIsMobileSidebarOpen(false)}
              />
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
