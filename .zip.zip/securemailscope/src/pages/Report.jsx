import React from 'react';
import ObservabilityLegend from '../components/ObservabilityLegend';
import ObservabilityPill from '../components/ObservabilityPill';
import SeverityBadge from '../components/SeverityBadge';
import RiskGauge from '../components/RiskGauge';
import { 
  Printer, 
  Download, 
  FileText, 
  Calendar, 
  Shield, 
  CheckCircle2, 
  AlertTriangle,
  Lock,
  Cpu,
  Server
} from 'lucide-react';

export default function Report({ scenario }) {
  const findings = [...(scenario.findings || [])].sort((a, b) => a.priorityRank - b.priorityRank);
  const crypto = scenario.cryptoDiscovery;
  const traffic = scenario.trafficOverview;

  const handlePrint = () => {
    window.print();
  };

  const timestamp = new Date().toUTCString();

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Action Bar (Hidden in Print) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print pb-2">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-400" />
            Executive Cryptographic Assessment Report
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Formal technical evaluation documentation formatted for compliance audit and CISO briefing.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-black font-semibold text-xs font-mono transition-all shadow-md shadow-sky-500/20"
          >
            <Printer className="w-4 h-4" />
            <span>Download / Print PDF Report</span>
          </button>
        </div>
      </div>

      {/* Observability Legend (Mandatory) */}
      <ObservabilityLegend className="no-print" />

      {/* Printable Report Canvas */}
      <div className="bg-[#111827] border border-[#1F2937] rounded-2xl p-6 sm:p-10 space-y-8 shadow-xl text-gray-200 soc-card print:border-gray-300">
        {/* Document Header */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b border-[#1F2937]">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-sky-500 flex items-center justify-center text-white">
                <Shield className="w-4 h-4" />
              </span>
              <span className="font-bold text-lg text-white font-mono tracking-tight">
                SecureMail<span className="text-sky-400">Scope</span>
              </span>
              <span className="px-2 py-0.5 rounded bg-gray-800 text-[10px] font-mono text-gray-300">
                AUDIT AUD-2026-X9
              </span>
            </div>
            <h1 className="text-xl font-extrabold text-white">
              Cryptographic Posture & Protocol Integrity Assessment
            </h1>
            <p className="text-xs text-gray-400 font-mono">
              Target Evaluation Subject: <strong className="text-gray-200">{scenario.name}</strong>
            </p>
          </div>

          <div className="text-left sm:text-right font-mono text-xs text-gray-400 space-y-1">
            <div className="flex items-center sm:justify-end gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-sky-400" />
              <span>{timestamp}</span>
            </div>
            <div>Capture File: <span className="text-sky-300">{scenario.uploadedFile.name}</span></div>
            <div>Classification: <span className="text-emerald-400 font-semibold">SYNTHETIC BENCHMARK</span></div>
          </div>
        </div>

        {/* Executive Summary Block */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-[#0B0F14] border border-[#1F2937] rounded-xl p-6">
          <div className="md:col-span-4 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-[#1F2937] pb-4 md:pb-0 md:pr-6">
            <RiskGauge score={scenario.riskScore.overall} band={scenario.riskScore.band} size={180} />
          </div>

          <div className="md:col-span-8 space-y-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-sky-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-sky-400 font-mono">
                Executive Synthesis
              </h3>
            </div>
            <p className="text-xs text-gray-300 leading-relaxed">
              {scenario.aiSummary}
            </p>
            <div className="grid grid-cols-3 gap-2 pt-2 text-[11px] font-mono">
              <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                <span className="text-gray-500 block text-[10px]">Total Sessions</span>
                <span className="text-white font-bold">{traffic.emailSessions}</span>
              </div>
              <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                <span className="text-gray-500 block text-[10px]">TLS Sessions</span>
                <span className="text-emerald-400 font-bold">{traffic.tlsSessions}</span>
              </div>
              <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                <span className="text-gray-500 block text-[10px]">Plaintext</span>
                <span className={traffic.unencryptedSessions > 0 ? "text-red-400 font-bold" : "text-gray-400 font-bold"}>
                  {traffic.unencryptedSessions}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Cryptographic Parameter Discovery Summary */}
        <div className="space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300 font-mono flex items-center gap-2">
              <Lock className="w-4 h-4 text-sky-400" />
              Dissected Cryptographic Parameters (Ground-Truth Ledger)
            </h3>
            <span className="text-[11px] font-mono text-gray-500">Observability Verified</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#1F2937] text-gray-500 text-[10px] uppercase">
                  <th className="py-2 pr-4">Parameter</th>
                  <th className="py-2 px-4">Dissected Value</th>
                  <th className="py-2 px-4">Observability Standard</th>
                  <th className="py-2 pl-4">Cryptographic Context</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F2937]/70">
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.tlsVersion.label}</td>
                  <td className="py-2.5 px-4 text-sky-300 font-bold">{crypto.tlsVersion.value}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.tlsVersion.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.tlsVersion.note}</td>
                </tr>
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.cipherSuite.label}</td>
                  <td className="py-2.5 px-4 text-sky-300 font-bold">{crypto.cipherSuite.value}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.cipherSuite.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.cipherSuite.note}</td>
                </tr>
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.keyExchange.label}</td>
                  <td className="py-2.5 px-4 text-sky-300">{crypto.keyExchange.value}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.keyExchange.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.keyExchange.note}</td>
                </tr>
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.certificate.keyType.label}</td>
                  <td className="py-2.5 px-4 text-gray-300">{crypto.certificate.keyType.value ?? 'Not observable from PCAP'}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.certificate.keyType.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.certificate.keyType.note}</td>
                </tr>
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.certificate.keySize.label}</td>
                  <td className="py-2.5 px-4 text-gray-300">{crypto.certificate.keySize.value ?? 'Not observable from PCAP'}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.certificate.keySize.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.certificate.keySize.note}</td>
                </tr>
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.certificate.sigAlg.label}</td>
                  <td className="py-2.5 px-4 text-gray-300">{crypto.certificate.sigAlg.value ?? 'Not observable from PCAP'}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.certificate.sigAlg.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.certificate.sigAlg.note}</td>
                </tr>
                <tr>
                  <td className="py-2.5 pr-4 text-gray-300 font-semibold">{crypto.smime.label}</td>
                  <td className="py-2.5 px-4 text-gray-300">{crypto.smime.value ?? 'Not observable from PCAP'}</td>
                  <td className="py-2.5 px-4"><ObservabilityPill status={crypto.smime.observability} size="xs" /></td>
                  <td className="py-2.5 pl-4 text-[11px] text-gray-400">{crypto.smime.note}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Findings & Vulnerability Summary */}
        <div className="space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300 font-mono flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Identified Vulnerabilities & Remediations ({findings.length})
            </h3>
            <span className="text-[11px] font-mono text-gray-500">Prioritized Action Items</span>
          </div>

          <div className="space-y-3">
            {findings.map((finding) => (
              <div 
                key={finding.id}
                className="bg-[#0B0F14] border border-[#1F2937] rounded-xl p-4 space-y-2 text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sky-400 bg-[#161B22] px-2 py-0.5 rounded border border-[#1F2937]">
                      Priority {finding.priorityRank}
                    </span>
                    <span className="font-semibold text-white">{finding.title}</span>
                  </div>
                  <SeverityBadge severity={finding.severity} size="xs" />
                </div>

                <p className="text-gray-300 text-[11px] leading-relaxed">
                  <strong>Risk: </strong>{finding.whyDangerous}
                </p>

                <div className="p-2 rounded bg-[#161B22] border border-[#1F2937] text-[11px] font-mono text-emerald-300">
                  <strong>Mandated Remediation: </strong>{finding.recommendedFix}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Audit Signoff Footer */}
        <div className="pt-6 border-t border-[#1F2937] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-gray-400">
          <div>
            <span>Generated by </span>
            <strong className="text-white">SecureMailScope v2.4 (SOC Posture Engine)</strong>
          </div>
          <div>
            <span>Validation Hash: </span>
            <span className="text-sky-400">sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1f</span>
          </div>
        </div>
      </div>
    </div>
  );
}
