import React, { useState } from 'react';
import ObservabilityLegend from '../components/ObservabilityLegend';
import ObservabilityPill from '../components/ObservabilityPill';
import { 
  Network, 
  Lock, 
  Key, 
  ShieldCheck, 
  FileCheck, 
  Mail, 
  AlertCircle, 
  Info, 
  Server, 
  Filter,
  CheckCircle2,
  XCircle,
  HelpCircle
} from 'lucide-react';

export default function Discovery({ scenario }) {
  const [filter, setFilter] = useState('all'); // 'all' | 'observed' | 'inferred' | 'not_observable'
  const crypto = scenario.cryptoDiscovery;
  const traffic = scenario.trafficOverview;

  // Flatten discovery fields for systematic tabular display
  const discoveryRows = [
    {
      id: 'tlsVersion',
      category: 'Protocol Layer',
      icon: Lock,
      label: crypto.tlsVersion.label,
      value: crypto.tlsVersion.value,
      observability: crypto.tlsVersion.observability,
      note: crypto.tlsVersion.note
    },
    {
      id: 'cipherSuite',
      category: 'Symmetric Cipher',
      icon: ShieldCheck,
      label: crypto.cipherSuite.label,
      value: crypto.cipherSuite.value,
      observability: crypto.cipherSuite.observability,
      note: crypto.cipherSuite.note
    },
    {
      id: 'keyExchange',
      category: 'Key Agreement',
      icon: Key,
      label: crypto.keyExchange.label,
      value: crypto.keyExchange.value,
      observability: crypto.keyExchange.observability,
      note: crypto.keyExchange.note
    },
    {
      id: 'pfs',
      category: 'Key Agreement',
      icon: Key,
      label: crypto.pfsEnabled.label,
      value: crypto.pfsEnabled.value,
      observability: crypto.pfsEnabled.observability,
      note: crypto.pfsEnabled.note
    },
    {
      id: 'certKeyType',
      category: 'X.509 Identity',
      icon: FileCheck,
      label: crypto.certificate.keyType.label,
      value: crypto.certificate.keyType.value,
      observability: crypto.certificate.keyType.observability,
      note: crypto.certificate.keyType.note
    },
    {
      id: 'certKeySize',
      category: 'X.509 Identity',
      icon: FileCheck,
      label: crypto.certificate.keySize.label,
      value: crypto.certificate.keySize.value,
      observability: crypto.certificate.keySize.observability,
      note: crypto.certificate.keySize.note
    },
    {
      id: 'certSigAlg',
      category: 'X.509 Identity',
      icon: FileCheck,
      label: crypto.certificate.sigAlg.label,
      value: crypto.certificate.sigAlg.value,
      observability: crypto.certificate.sigAlg.observability,
      note: crypto.certificate.sigAlg.note
    },
    {
      id: 'certSan',
      category: 'X.509 Identity',
      icon: FileCheck,
      label: crypto.certificate.sanDomains?.label || 'Subject Alternative Names (SAN)',
      value: crypto.certificate.sanDomains?.value || null,
      observability: crypto.certificate.sanDomains?.observability || 'not_observable',
      note: crypto.certificate.sanDomains?.note
    },
    {
      id: 'sigAlgOffered',
      category: 'Handshake Extensions',
      icon: Lock,
      label: crypto.signatureAlgOffered.label,
      value: crypto.signatureAlgOffered.value,
      observability: crypto.signatureAlgOffered.observability,
      note: crypto.signatureAlgOffered.note
    },
    {
      id: 'smime',
      category: 'Email Payload Layer',
      icon: Mail,
      label: crypto.smime.label,
      value: crypto.smime.value,
      observability: crypto.smime.observability,
      note: crypto.smime.note
    },
    {
      id: 'pgp',
      category: 'Email Payload Layer',
      icon: Mail,
      label: crypto.pgp.label,
      value: crypto.pgp.value,
      observability: crypto.pgp.observability,
      note: crypto.pgp.note
    },
    {
      id: 'deprecatedHash',
      category: 'Integrity Primitives',
      icon: AlertCircle,
      label: crypto.hashDeprecatedFound.label,
      value: crypto.hashDeprecatedFound.value === null ? null : (crypto.hashDeprecatedFound.value ? "TRUE — Insecure digest identified" : "FALSE — No deprecated hash found"),
      observability: crypto.hashDeprecatedFound.observability,
      note: crypto.hashDeprecatedFound.note
    }
  ];

  const filteredRows = discoveryRows.filter(row => {
    if (filter === 'all') return true;
    return row.observability === filter;
  });

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Cryptographic Discovery & Handshake Extraction
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          Detailed cryptographic parameter telemetry dissected directly from packet capture frames.
        </p>
      </div>

      {/* Mandatory Observability Legend */}
      <ObservabilityLegend />

      {/* Traffic Overview Stat Row */}
      <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
            <Network className="w-4 h-4 text-sky-400" />
            Network Traffic & Session Overview
          </h3>
          <span className="text-[11px] font-mono text-gray-400">
            Source PCAP: {scenario.uploadedFile.name}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">Total Packets</span>
            <span className="text-base font-mono font-bold text-white">
              {traffic.totalPackets.toLocaleString()}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">Email Sessions</span>
            <span className="text-base font-mono font-bold text-sky-400">
              {traffic.emailSessions}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">TLS Protected</span>
            <span className="text-base font-mono font-bold text-emerald-400">
              {traffic.tlsSessions}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">Plaintext Cleartext</span>
            <span className={`text-base font-mono font-bold ${traffic.unencryptedSessions > 0 ? 'text-red-400' : 'text-gray-400'}`}>
              {traffic.unencryptedSessions}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">STARTTLS Negotiated</span>
            <span className="text-base font-mono font-bold text-gray-200">
              {traffic.starttlsNegotiated ?? traffic.tlsSessions}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937]">
            <span className="text-[10px] uppercase font-mono text-gray-500 block">Plaintext Fallbacks</span>
            <span className={`text-base font-mono font-bold ${traffic.plaintextFallbacks > 0 ? 'text-orange-400' : 'text-gray-400'}`}>
              {traffic.plaintextFallbacks ?? traffic.unencryptedSessions}
            </span>
          </div>
        </div>

        {/* Server & Client Endpoints */}
        <div className="mt-3 pt-3 border-t border-[#1F2937]/70 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-gray-500">Destination Relay:</span>
            <span className="text-sky-300 font-semibold">{traffic.serverIPs?.join(', ') || 'N/A'}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-500">Client Endpoints:</span>
            <span className="text-gray-300">{traffic.clientIPs?.join(', ') || 'Various'}</span>
          </div>
        </div>
      </div>

      {/* Cryptographic Discovery Table */}
      <div className="bg-[#161B22] border border-[#1F2937] rounded-xl overflow-hidden shadow-sm">
        {/* Table Header Controls */}
        <div className="p-4 border-b border-[#1F2937] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111827]">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-200">
              Cryptographic Telemetry Ledger
            </h3>
            <span className="text-[11px] font-mono text-gray-500">
              ({filteredRows.length} parameters)
            </span>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 bg-[#0B0F14] p-1 rounded-lg border border-[#1F2937]">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors ${
                filter === 'all' ? 'bg-sky-500/20 text-sky-300 font-semibold' : 'text-gray-400 hover:text-white'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('observed')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors ${
                filter === 'observed' ? 'bg-emerald-500/20 text-emerald-300 font-semibold' : 'text-gray-400 hover:text-white'
              }`}
            >
              🟢 Observed
            </button>
            <button
              onClick={() => setFilter('inferred')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors ${
                filter === 'inferred' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-gray-400 hover:text-white'
              }`}
            >
              🟡 Inferred
            </button>
            <button
              onClick={() => setFilter('not_observable')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors ${
                filter === 'not_observable' ? 'bg-gray-800 text-gray-200 font-semibold' : 'text-gray-400 hover:text-white'
              }`}
            >
              ⚪ Not Observable
            </button>
          </div>
        </div>

        {/* Structured Data Rows */}
        <div className="divide-y divide-[#1F2937]">
          {filteredRows.map((row) => {
            const isNull = row.value === null || row.value === undefined;
            const Icon = row.icon;

            return (
              <div 
                key={row.id}
                className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-[#111827]/40 transition-colors"
              >
                {/* Parameter Info */}
                <div className="md:w-1/3 flex items-start gap-3">
                  <div className="p-2 rounded bg-[#0B0F14] border border-[#1F2937] text-gray-400 shrink-0 mt-0.5">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono uppercase text-gray-500 block">
                      {row.category}
                    </span>
                    <span className="text-xs font-semibold text-gray-200">
                      {row.label}
                    </span>
                  </div>
                </div>

                {/* Extracted Value */}
                <div className="md:w-1/2">
                  {!isNull ? (
                    <span className="font-mono text-xs font-semibold text-sky-300 bg-[#0B0F14] px-2.5 py-1 rounded border border-[#1F2937] inline-block break-all">
                      {String(row.value)}
                    </span>
                  ) : (
                    <span className="font-mono text-xs text-gray-500 italic bg-[#0B0F14]/50 px-2.5 py-1 rounded border border-dashed border-gray-800 inline-block">
                      Not observable from PCAP
                    </span>
                  )}
                  {row.note && (
                    <p className="text-[11px] text-gray-400 mt-1.5 leading-snug flex items-start gap-1">
                      <Info className="w-3 h-3 text-gray-500 shrink-0 mt-0.5" />
                      <span>{row.note}</span>
                    </p>
                  )}
                </div>

                {/* Observability Pill */}
                <div className="md:w-1/6 flex justify-start md:justify-end items-center">
                  <ObservabilityPill status={row.observability} note={row.note} size="xs" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
