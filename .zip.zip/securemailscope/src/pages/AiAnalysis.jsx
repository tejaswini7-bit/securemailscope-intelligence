import React from 'react';
import ObservabilityLegend from '../components/ObservabilityLegend';
import SeverityBadge from '../components/SeverityBadge';
import ObservabilityPill from '../components/ObservabilityPill';
import { Sparkles, BrainCircuit, ShieldAlert, Cpu, CheckCircle2, Lock, FileText, AlertTriangle } from 'lucide-react';

export default function AiAnalysis({ scenario }) {
  const findings = scenario.findings || [];

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white tracking-tight">
            AI Cryptographic Posture Reasoning Engine
          </h2>
          <span className="flex items-center gap-1 text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400">
            <Sparkles className="w-3 h-3" />
            SYNTHESIS ENGINE
          </span>
        </div>
        <p className="text-xs text-gray-400 mt-1">
          Automated heuristic reasoning synthesizing observed handshake parameters, standard RFC deprecations, and compounding attack paths.
        </p>
      </div>

      {/* Observability Legend */}
      <ObservabilityLegend />

      {/* Distinct AI Global Assessment Panel */}
      <div className="bg-[#111827] border-l-4 border-l-sky-400 border-y border-r border-[#1F2937] rounded-r-xl p-6 shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <BrainCircuit className="w-32 h-32 text-sky-400" />
        </div>

        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white font-mono">
                  Executive AI Cryptographic Summary
                </h3>
                <span className="px-2 py-0.2 rounded text-[10px] font-mono bg-sky-950/80 border border-sky-500/40 text-sky-300">
                  AI-generated analysis
                </span>
              </div>
              <span className="text-[11px] text-gray-400 font-mono">
                Heuristic inference over {findings.length} observed telemetry vector(s)
              </span>
            </div>
          </div>

          <div className="hidden sm:block text-right">
            <span className="text-[10px] font-mono text-gray-500 block uppercase">Calculated Posture</span>
            <span className="text-xs font-mono font-bold text-sky-300">
              {scenario.riskScore.overall}/100 • {scenario.riskScore.band}
            </span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0F14]/70 border border-[#1F2937] text-gray-200 text-xs leading-relaxed font-sans">
          {scenario.aiSummary}
        </div>

        <div className="mt-4 flex items-center gap-2 text-[11px] text-gray-400">
          <Cpu className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span>
            <strong>Architectural note:</strong> The AI engine operates strictly as an explanatory synthesis layer over structured PCAP extraction; posture scores are calculated via deterministic formulas rather than black-box approximations.
          </span>
        </div>
      </div>

      {/* CIA Triad Threat Vector Assessment */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Confidentiality */}
        <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <span className="text-xs font-bold font-mono text-gray-200 uppercase flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-sky-400" />
              Confidentiality
            </span>
            <span className="text-[10px] font-mono text-gray-500">CIA Pillar I</span>
          </div>
          <p className="text-[11px] text-gray-400 leading-relaxed">
            {scenario.id === 'scenario_a' 
              ? 'Protected by TLS 1.3 AES-256-GCM authenticated encryption and ephemeral X25519 forward secrecy. No passive eavesdropping feasible.'
              : scenario.id === 'scenario_b'
              ? 'Partially degraded: 6 unencrypted SMTP sessions expose message contents, and CBC cipher mode in TLS 1.2 is susceptible to timing side channels.'
              : 'Severely compromised: Static RSA allows bulk retroactive decryption of recorded sessions, and RC4 keystream biases permit plaintext recovery.'}
          </p>
        </div>

        {/* Integrity */}
        <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <span className="text-xs font-bold font-mono text-gray-200 uppercase flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Integrity
            </span>
            <span className="text-[10px] font-mono text-gray-500">CIA Pillar II</span>
          </div>
          <p className="text-[11px] text-gray-400 leading-relaxed">
            {scenario.id === 'scenario_a'
              ? 'Cryptographic integrity guaranteed via AEAD Poly1305/GCM primitives and SHA-384 message authentication codes.'
              : scenario.id === 'scenario_b'
              ? 'Undermined by SHA-1 certificate signature hash collision risk and cleartext modification opportunities on unencrypted sessions.'
              : 'Critical failure: TLS 1.0 dual MD5/SHA-1 PRF is susceptible to manipulation, and SHA-1 certificate signatures can be practically forged.'}
          </p>
        </div>

        {/* Authentication */}
        <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <span className="text-xs font-bold font-mono text-gray-200 uppercase flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              Authentication
            </span>
            <span className="text-[10px] font-mono text-gray-500">CIA Pillar III</span>
          </div>
          <p className="text-[11px] text-gray-400 leading-relaxed">
            {scenario.id === 'scenario_a'
              ? 'Modern signature algorithms supported; certificate exchange encrypted inside TLS 1.3 to prevent identity profiling.'
              : scenario.id === 'scenario_b'
              ? 'Certificate identity verified with RSA-2048, but authenticity is compromised by the obsolete SHA-1 signing algorithm.'
              : 'Inadequate: Insecure 1024-bit RSA modulus and SHA-1 signature allow impersonation and rogue certificate spoofing by capable threat actors.'}
          </p>
        </div>
      </div>

      {/* Granular AI Narrative Groupings Per Finding */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            Deep-Dive Narrative Reasoning by Finding
          </h3>
          <span className="text-[11px] font-mono text-gray-500">
            {findings.length} findings evaluated
          </span>
        </div>

        {findings.map((finding, idx) => (
          <div 
            key={finding.id}
            className="bg-[#161B22] border border-[#1F2937] rounded-xl p-5 space-y-3 shadow-sm hover:border-gray-700 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#1F2937]">
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs font-bold text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-500/30">
                  #{finding.priorityRank}
                </span>
                <h4 className="text-sm font-semibold text-gray-100">
                  {finding.title}
                </h4>
              </div>

              <div className="flex items-center gap-2">
                <SeverityBadge severity={finding.severity} size="xs" />
                <ObservabilityPill status={finding.observability} size="xs" />
              </div>
            </div>

            {/* AI Narrative Content */}
            <div className="p-3.5 rounded-lg bg-[#111827] border-l-2 border-sky-400 text-xs text-gray-300 leading-relaxed">
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold block mb-1">
                Contextual AI Narrative
              </span>
              {finding.aiNarrative}
            </div>

            {/* Evidence & Action Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
              <div className="bg-[#0B0F14] p-3 rounded-lg border border-[#1F2937]">
                <span className="text-[10px] font-mono uppercase text-gray-500 block mb-1">
                  Corroborating Dissection Evidence
                </span>
                <code className="text-[11px] font-mono text-gray-300 break-all">
                  {finding.detected}
                </code>
              </div>

              <div className="bg-[#0B0F14] p-3 rounded-lg border border-[#1F2937]">
                <span className="text-[10px] font-mono uppercase text-emerald-400 block mb-1">
                  Remediation Objective
                </span>
                <p className="text-[11px] text-gray-300">
                  {finding.recommendedFix}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
