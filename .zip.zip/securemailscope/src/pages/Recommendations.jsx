import React, { useState } from 'react';
import SeverityBadge from '../components/SeverityBadge';
import { 
  Wrench, 
  CheckSquare, 
  Square, 
  Terminal, 
  Copy, 
  Check, 
  ShieldCheck, 
  Server, 
  ExternalLink,
  AlertTriangle 
} from 'lucide-react';

export default function Recommendations({ scenario }) {
  const [completedItems, setCompletedItems] = useState({});
  const [copiedConfig, setCopiedConfig] = useState(null);

  const findings = scenario.findings || [];

  const toggleCheck = (id) => {
    setCompletedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const copyConfigSnippet = (key, text) => {
    navigator.clipboard?.writeText(text);
    setCopiedConfig(key);
    setTimeout(() => setCopiedConfig(null), 2000);
  };

  // Group findings by severity
  const criticalFindings = findings.filter(f => f.severity === 'critical');
  const highFindings = findings.filter(f => f.severity === 'high');
  const mediumFindings = findings.filter(f => f.severity === 'medium');
  const lowFindings = findings.filter(f => f.severity === 'low' || f.severity === 'info');

  // Hardened Configuration Snippets for MTAs
  const postfixSnippet = `# Postfix main.cf - Recommended Modern Cryptographic Baseline
# 1. Enforce TLS for incoming and outgoing mail
smtpd_tls_security_level = encrypt
smtp_tls_security_level = dane
smtpd_tls_mandatory_protocols = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1, TLSv1.2, TLSv1.3
smtpd_tls_protocols = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1, TLSv1.2, TLSv1.3

# 2. Modern AEAD Ciphers Only (Disable RC4, CBC, 3DES)
smtpd_tls_mandatory_ciphers = high
tls_high_cipherlist = ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256
smtpd_tls_eecdh_grade = ultra

# 3. Require Modern Certificates (SHA-256+ with RSA-2048 or ECDSA)
smtpd_tls_cert_file = /etc/ssl/certs/mail_domain_sha256.crt
smtpd_tls_key_file = /etc/ssl/private/mail_domain.key`;

  const nginxSnippet = `# Nginx Mail Proxy mail { } block
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256';
ssl_prefer_server_ciphers on;
ssl_session_cache shared:SSL:10m;
ssl_session_timeout 1d;
ssl_session_tickets off;
ssl_ecdh_curve X25519:prime256v1:secp384r1;`;

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Remediation Plan & Mail Server Hardening Guidance
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          Severity-grouped action items, deployment checklists, and vendor-validated MTA configuration baselines.
        </p>
      </div>

      {/* Action Groups by Severity */}
      <div className="space-y-6">
        {/* 🔴 Critical Severity Actions */}
        {criticalFindings.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-red-500/30">
              <span className="text-sm">🔴</span>
              <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-red-400">
                Critical Priority Remediations ({criticalFindings.length}) — Immediate Action Required
              </h3>
            </div>

            <div className="space-y-2.5">
              {criticalFindings.map((item) => {
                const isChecked = !!completedItems[item.id];
                return (
                  <div
                    key={item.id}
                    className={`bg-[#161B22] border rounded-xl p-4 transition-all ${
                      isChecked 
                        ? 'border-emerald-500/40 bg-emerald-950/10 opacity-70' 
                        : 'border-red-900/40 hover:border-red-600/50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleCheck(item.id)}
                        className="mt-0.5 text-gray-400 hover:text-white transition-colors"
                        title={isChecked ? "Mark incomplete" : "Mark as completed"}
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className={`text-xs font-semibold ${isChecked ? 'line-through text-gray-400' : 'text-gray-100'}`}>
                            {item.title}
                          </span>
                          <SeverityBadge severity={item.severity} size="xs" />
                        </div>

                        <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937] text-xs font-mono text-emerald-300 mt-2">
                          <strong className="text-gray-400 uppercase text-[10px] block mb-0.5">Action Directive:</strong>
                          {item.recommendedFix}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 🟠 High Severity Actions */}
        {highFindings.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-orange-500/30">
              <span className="text-sm">🟠</span>
              <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-orange-400">
                High Priority Remediations ({highFindings.length}) — Schedule in Next Release Window
              </h3>
            </div>

            <div className="space-y-2.5">
              {highFindings.map((item) => {
                const isChecked = !!completedItems[item.id];
                return (
                  <div
                    key={item.id}
                    className={`bg-[#161B22] border rounded-xl p-4 transition-all ${
                      isChecked 
                        ? 'border-emerald-500/40 bg-emerald-950/10 opacity-70' 
                        : 'border-orange-900/40 hover:border-orange-600/50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleCheck(item.id)}
                        className="mt-0.5 text-gray-400 hover:text-white transition-colors"
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className={`text-xs font-semibold ${isChecked ? 'line-through text-gray-400' : 'text-gray-100'}`}>
                            {item.title}
                          </span>
                          <SeverityBadge severity={item.severity} size="xs" />
                        </div>

                        <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937] text-xs font-mono text-orange-300 mt-2">
                          <strong className="text-gray-400 uppercase text-[10px] block mb-0.5">Action Directive:</strong>
                          {item.recommendedFix}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 🟡 Medium Severity Actions */}
        {mediumFindings.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-amber-500/30">
              <span className="text-sm">🟡</span>
              <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-amber-400">
                Medium Priority Actions ({mediumFindings.length}) — Hardening & Defense-in-Depth
              </h3>
            </div>

            <div className="space-y-2.5">
              {mediumFindings.map((item) => {
                const isChecked = !!completedItems[item.id];
                return (
                  <div
                    key={item.id}
                    className={`bg-[#161B22] border rounded-xl p-4 transition-all ${
                      isChecked 
                        ? 'border-emerald-500/40 bg-emerald-950/10 opacity-70' 
                        : 'border-amber-900/40 hover:border-amber-600/50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleCheck(item.id)}
                        className="mt-0.5 text-gray-400 hover:text-white transition-colors"
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className={`text-xs font-semibold ${isChecked ? 'line-through text-gray-400' : 'text-gray-100'}`}>
                            {item.title}
                          </span>
                          <SeverityBadge severity={item.severity} size="xs" />
                        </div>

                        <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937] text-xs font-mono text-amber-300 mt-2">
                          <strong className="text-gray-400 uppercase text-[10px] block mb-0.5">Action Directive:</strong>
                          {item.recommendedFix}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 🟢 Low / Info Actions */}
        {lowFindings.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-emerald-500/30">
              <span className="text-sm">🟢</span>
              <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-emerald-400">
                Low Priority / Hygiene Items ({lowFindings.length}) — Security Hygiene Observations
              </h3>
            </div>

            <div className="space-y-2.5">
              {lowFindings.map((item) => {
                const isChecked = !!completedItems[item.id];
                return (
                  <div
                    key={item.id}
                    className={`bg-[#161B22] border rounded-xl p-4 transition-all ${
                      isChecked 
                        ? 'border-emerald-500/40 bg-emerald-950/10 opacity-70' 
                        : 'border-[#1F2937] hover:border-gray-600'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleCheck(item.id)}
                        className="mt-0.5 text-gray-400 hover:text-white transition-colors"
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className={`text-xs font-semibold ${isChecked ? 'line-through text-gray-400' : 'text-gray-100'}`}>
                            {item.title}
                          </span>
                          <SeverityBadge severity={item.severity} size="xs" />
                        </div>

                        <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#1F2937] text-xs font-mono text-gray-300 mt-2">
                          <strong className="text-gray-400 uppercase text-[10px] block mb-0.5">Action Directive:</strong>
                          {item.recommendedFix}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Production Hardening Snippets Section */}
      <div className="bg-[#111827] border border-[#1F2937] rounded-xl p-6 space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-200">
              Ready-to-Apply MTA Hardening Configurations
            </h3>
          </div>
          <span className="text-[11px] font-mono text-gray-500">
            NIST SP 800-52r2 & RFC 8996 Compliant
          </span>
        </div>

        {/* Postfix Config Card */}
        <div className="bg-[#0B0F14] border border-[#1F2937] rounded-lg p-4 space-y-2 font-mono">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <span className="text-xs text-sky-300 font-bold">
              Postfix MTA Configuration (/etc/postfix/main.cf)
            </span>
            <button
              onClick={() => copyConfigSnippet('postfix', postfixSnippet)}
              className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 transition-colors"
            >
              {copiedConfig === 'postfix' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copiedConfig === 'postfix' ? 'Copied' : 'Copy Snippet'}</span>
            </button>
          </div>
          <pre className="text-[11px] text-gray-300 whitespace-pre-wrap overflow-x-auto leading-relaxed">
            {postfixSnippet}
          </pre>
        </div>

        {/* Nginx Mail Proxy Config Card */}
        <div className="bg-[#0B0F14] border border-[#1F2937] rounded-lg p-4 space-y-2 font-mono">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <span className="text-xs text-sky-300 font-bold">
              Nginx Mail Reverse Proxy (/etc/nginx/nginx.conf)
            </span>
            <button
              onClick={() => copyConfigSnippet('nginx', nginxSnippet)}
              className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 transition-colors"
            >
              {copiedConfig === 'nginx' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copiedConfig === 'nginx' ? 'Copied' : 'Copy Snippet'}</span>
            </button>
          </div>
          <pre className="text-[11px] text-gray-300 whitespace-pre-wrap overflow-x-auto leading-relaxed">
            {nginxSnippet}
          </pre>
        </div>
      </div>
    </div>
  );
}
