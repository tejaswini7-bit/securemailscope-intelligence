import React, { useState } from 'react';
import UploadDropzone from '../components/UploadDropzone';
import AnalysisProgress from '../components/AnalysisProgress';

export default function PcapAnalyzer({ scenario, onNavigate }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleStartAnalysis = () => {
    setIsAnalyzing(true);
  };

  const handleAnalysisComplete = () => {
    setIsAnalyzing(false);
    onNavigate('discovery');
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          PCAP Deep Cryptographic Analyzer
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          Ingest raw network packet captures to dissect TLS records, X.509 certificate chains, and email payload encryption.
        </p>
      </div>

      {!isAnalyzing ? (
        <UploadDropzone 
          scenario={scenario} 
          onStartAnalysis={handleStartAnalysis} 
        />
      ) : (
        <AnalysisProgress 
          scenario={scenario} 
          onComplete={handleAnalysisComplete} 
        />
      )}
    </div>
  );
}
