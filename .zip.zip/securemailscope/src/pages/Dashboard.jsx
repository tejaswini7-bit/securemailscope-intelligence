import React from 'react';
import RiskGauge from '../components/RiskGauge';
import MetricBreakdownBars from '../components/MetricBreakdownBars';
import PipelineStepper from '../components/PipelineStepper';
import SeverityBadge from '../components/SeverityBadge';
import { 
  ArrowRight, 
  ShieldAlert, 
  AlertTriangle, 
  AlertCircle, 
  AlertOctagon, 
  ShieldCheck, 
  Network, 
  Lock, 
  FileCode,
  Activity,
  Layers
} from 'lucide-react';

export default function Dashboard({ scenario, onNavigate }) {
  // Count findings by severity
  const findings = scenario.findings || [];
  const criticalCount = findings.filter(f => f.severity === 'critical').length;
  const highCount = findings.filter(f => f.severity === 'high').length;
  const mediumCount = findings.filter(f => f.severity === 'medium').length;
  const lowCount = findings.filter(f => f.severity === 'low' || f.severity === 'info').length;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-white tracking-tight">
              Cryptographic Posture Dashboard
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-sky-500/10 border border-sky-500/30 text-sky-400">
              {scenario.badgeLabel}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1 max-w-2xl leading-relaxed">
            {scenario.description}
          </p>
        </div>

        <button
          onClick={() => onNavigate('analyzer')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-black font-semibold text-xs font-mono transition-all shadow-md shadow-sky-500/20 self-start md:self-auto"
        >
          <span>Continue to PCAP Analyzer</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Severity Stat Cards (4 Cards) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        {/* Critical */}
        <div 
          onClick={() => onNavigate('risk-assessment')}
          className="bg-[#161B22] border border-[#1F2937] hover:border-red-500/50 p-4 rounded-xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase font-semibold text-red-400">
              Critical Risk
            </span>
            <AlertTriangle className="w-4 h-4 text-red-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {criticalCount}
            </span>
            <span className="text-[10px] text-gray-400 font-mono">vulnerabilities</span>
          </div>
          <div className="mt-2 text-[10px] text-gray-500">
            Immediate mitigation mandatory
          </div>
        </div>

        {/* High */}
        <div 
          onClick={() => onNavigate('risk-assessment')}
          className="bg-[#161B22] border border-[#1F2937] hover:border-orange-500/50 p-4 rounded-xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase font-semibold text-orange-400">
              High Risk
            </span>
            <AlertCircle className="w-4 h-4 text-orange-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {highCount}
            </span>
            <span className="text-[10px] text-gray-400 font-mono">vulnerabilities</span>
          </div>
          <div className="mt-2 text-[10px] text-gray-500">
            High exposure attack paths
          </div>
        </div>

        {/* Medium */}
        <div 
          onClick={() => onNavigate('risk-assessment')}
          className="bg-[#161B22] border border-[#1F2937] hover:border-amber-500/50 p-4 rounded-xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase font-semibold text-amber-400">
              Medium Risk
            </span>
            <AlertOctagon className="w-4 h-4 text-amber-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {mediumCount}
            </span>
            <span className="text-[10px] text-gray-400 font-mono">vulnerabilities</span>
          </div>
          <div className="mt-2 text-[10px] text-gray-500">
            Sub-optimal configurations
          </div>
        </div>

        {/* Low / Info */}
        <div 
          onClick={() => onNavigate('risk-assessment')}
          className="bg-[#161B22] border border-[#1F2937] hover:border-emerald-500/50 p-4 rounded-xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase font-semibold text-emerald-400">
              Low / Info
            </span>
            <ShieldCheck className="w-4 h-4 text-emerald-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {lowCount}
            </span>
            <span className="text-[10px] text-gray-400 font-mono">observations</span>
          </div>
          <div className="mt-2 text-[10px] text-gray-500">
            Hygiene & telemetry notices
          </div>
        </div>
      </div>

      {/* Main Center Grid: Score Gauge + 5-Metric Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Center Risk Gauge Card */}
        <div className="lg:col-span-5 bg-[#161B22] border border-[#1F2937] rounded-xl p-6 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">
                Composite Security Posture
              </span>
              <span className="text-[11px] font-mono text-gray-500">
                Formula v2.1
              </span>
            </div>

            <div className="py-2">
              <RiskGauge 
                score={scenario.riskScore.overall} 
                band={scenario.riskScore.band} 
                size={230} 
              />
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-[#1F2937] space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-gray-400">Evaluated Target:</span>
              <span className="text-gray-200 font-semibold">{scenario.uploadedFile.name}</span>
            </div>
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-gray-400">Encrypted / Plaintext Sessions:</span>
              <span className="text-gray-200">
                <strong className="text-emerald-400">{scenario.trafficOverview.tlsSessions} TLS</strong> / <strong className={scenario.trafficOverview.unencryptedSessions > 0 ? 'text-red-400 font-bold' : 'text-gray-400'}>{scenario.trafficOverview.unencryptedSessions} Plaintext</strong>
              </span>
            </div>
          </div>
        </div>

        {/* 5-Metric Breakdown Dimension Bars */}
        <div className="lg:col-span-7 bg-[#161B22] border border-[#1F2937] rounded-xl p-6 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                Postural Security Dimensions
              </h3>
              <span className="text-[10px] font-mono text-gray-500">
                Observability Bound Evaluated
              </span>
            </div>
            <MetricBreakdownBars breakdown={scenario.riskScore.breakdown} />
          </div>

          <div className="mt-4 pt-3 border-t border-[#1F2937] flex items-center justify-between text-xs">
            <span className="text-gray-400 text-[11px]">
              * Dimensions marked "Not observable" reflect proper protocol opacity (e.g. TLS 1.3 handshake encryption).
            </span>
            <button
              onClick={() => onNavigate('discovery')}
              className="text-sky-400 hover:text-sky-300 font-mono text-xs font-semibold flex items-center gap-1 shrink-0"
            >
              <span>View Handshake</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Mini 10-Stage Pipeline Horizontal Stepper */}
      <PipelineStepper mode="compact" completed={true} />

      {/* Quick Summary & AI Excerpt */}
      <div className="bg-[#111827] border border-[#1F2937] rounded-xl p-5 flex flex-col sm:flex-row items-start gap-4">
        <div className="p-2.5 rounded-lg bg-blue-500/10 border border-sky-500/30 text-sky-400 shrink-0">
          <Activity className="w-5 h-5" />
        </div>
        <div className="space-y-1 flex-1">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-sky-400 font-mono">
            AI Cryptographic Posture Synthesis
          </h4>
          <p className="text-xs text-gray-300 leading-relaxed">
            {scenario.aiSummary}
          </p>
        </div>
        <button
          onClick={() => onNavigate('ai-analysis')}
          className="shrink-0 px-3 py-1.5 rounded-lg bg-[#161B22] hover:bg-gray-800 border border-[#1F2937] text-xs font-mono text-gray-300 hover:text-white transition-colors self-end sm:self-auto"
        >
          Inspect AI Engine &rarr;
        </button>
      </div>
    </div>
  );
}
