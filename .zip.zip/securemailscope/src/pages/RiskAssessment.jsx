import React, { useState } from 'react';
import RiskGauge from '../components/RiskGauge';
import MetricBreakdownBars from '../components/MetricBreakdownBars';
import FindingCard from '../components/FindingCard';
import { ShieldAlert, Filter, AlertTriangle, Layers } from 'lucide-react';

export default function RiskAssessment({ scenario }) {
  const [severityFilter, setSeverityFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const findings = scenario.findings || [];

  const filteredFindings = findings.filter(f => {
    const matchesSeverity = severityFilter === 'all' || f.severity === severityFilter;
    const matchesCategory = categoryFilter === 'all' || f.category === categoryFilter;
    return matchesSeverity && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Comprehensive Risk & Cryptographic Vulnerability Assessment
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          Quantitative cryptographic posture scoring coupled with granular vulnerability analysis across CIA security pillars.
        </p>
      </div>

      {/* Top Posture Evaluation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Risk Gauge Card */}
        <div className="lg:col-span-5 bg-[#161B22] border border-[#1F2937] rounded-xl p-6 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">
                Calculated Risk Score
              </span>
              <span className="text-[11px] font-mono text-gray-500">
                Confidence: High (PCAP Dissection)
              </span>
            </div>

            <div className="py-2">
              <RiskGauge 
                score={scenario.riskScore.overall} 
                band={scenario.riskScore.band} 
                size={230} 
              />
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-[#1F2937] text-xs text-gray-400 space-y-1 font-mono">
            <div className="flex justify-between">
              <span>Risk Band:</span>
              <span className="font-bold text-white">{scenario.riskScore.band}</span>
            </div>
            <div className="flex justify-between">
              <span>Dissected Traffic:</span>
              <span className="text-gray-200">{scenario.trafficOverview.totalPackets.toLocaleString()} frames</span>
            </div>
          </div>
        </div>

        {/* 5-Metric Posture Breakdown Bars */}
        <div className="lg:col-span-7 bg-[#161B22] border border-[#1F2937] rounded-xl p-6 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                Postural Security Dimensions
              </h3>
              <span className="text-[10px] font-mono text-gray-500">
                Dimensional Metrics
              </span>
            </div>
            <MetricBreakdownBars breakdown={scenario.riskScore.breakdown} />
          </div>

          <div className="mt-3 text-[11px] text-gray-400 italic">
            Note: Dimensions marked "Not scored (not observable)" reflect intentional TLS 1.3 protocol encryption boundaries.
          </div>
        </div>
      </div>

      {/* Findings Section */}
      <div className="space-y-4">
        {/* Header & Filter Controls */}
        <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-200">
              Vulnerability Ledger ({filteredFindings.length} of {findings.length})
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Severity Filter */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-gray-500 font-mono text-[11px]">Severity:</span>
              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value)}
                className="bg-[#0B0F14] border border-[#1F2937] text-gray-300 rounded px-2 py-1 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-sky-500"
              >
                <option value="all">All Severities</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
                <option value="info">Info</option>
              </select>
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-gray-500 font-mono text-[11px]">Category:</span>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-[#0B0F14] border border-[#1F2937] text-gray-300 rounded px-2 py-1 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-sky-500"
              >
                <option value="all">All Categories</option>
                <option value="confidentiality">Confidentiality</option>
                <option value="integrity">Integrity</option>
                <option value="authentication">Authentication</option>
              </select>
            </div>
          </div>
        </div>

        {/* Findings List */}
        {filteredFindings.length > 0 ? (
          <div className="space-y-3">
            {filteredFindings.map((finding) => (
              <FindingCard 
                key={finding.id} 
                finding={finding} 
                showPriorityRank={true}
                defaultExpanded={finding.severity === 'critical'}
              />
            ))}
          </div>
        ) : (
          <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-8 text-center text-gray-400 space-y-2">
            <p className="text-sm font-mono">No vulnerabilities match the selected filter criteria.</p>
            <button
              onClick={() => { setSeverityFilter('all'); setCategoryFilter('all'); }}
              className="text-xs text-sky-400 hover:underline font-mono"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
