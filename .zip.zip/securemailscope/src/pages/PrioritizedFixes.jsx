import React, { useState } from 'react';
import SeverityBadge from '../components/SeverityBadge';
import ObservabilityPill from '../components/ObservabilityPill';
import { 
  ListOrdered, 
  Calculator, 
  Wrench, 
  ShieldAlert, 
  ChevronDown, 
  ChevronUp, 
  Copy, 
  Check, 
  Tag, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { calculatePriorityScore } from '../utils/scoring';

export default function PrioritizedFixes({ scenario }) {
  const [copiedId, setCopiedId] = useState(null);
  const [expandedId, setExpandedId] = useState(null);

  const findings = [...(scenario.findings || [])].sort((a, b) => a.priorityRank - b.priorityRank);

  const handleCopy = (id, text) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleFormula = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Prioritized Remediation Backlog
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          Algorithmic remediation order sorted by impact severity, exploitability index, and active protocol deprecation factors.
        </p>
      </div>

      {/* Transparent Formula Methodology Banner */}
      <div className="bg-[#111827] border border-[#1F2937] rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20 shrink-0">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-gray-200 uppercase font-mono">
              Transparent Priority Calculation Methodology
            </h4>
            <p className="text-xs text-gray-400 font-mono mt-0.5">
              Rank Score = <span className="text-sky-300">(Severity × 4) + (Exploitability × 3) + (Exposure × 3) + (Deprecated ? 15 : 0)</span>
            </p>
          </div>
        </div>

        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full shrink-0">
          DETERMINISTIC RANKING
        </span>
      </div>

      {/* Prioritized List */}
      <div className="space-y-4">
        {findings.length > 0 ? (
          findings.map((item) => {
            const score = calculatePriorityScore(item.priorityScoreBreakdown);
            const isFormulaExpanded = expandedId === item.id;
            const b = item.priorityScoreBreakdown;

            return (
              <div 
                key={item.id}
                className="bg-[#161B22] border border-[#1F2937] hover:border-gray-700 rounded-xl p-5 space-y-4 transition-all shadow-sm"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1F2937]">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-[#0B0F14] border border-sky-500/40 flex items-center justify-center font-mono font-extrabold text-sm text-sky-300 shadow-sm">
                      {item.priorityRank < 10 ? `0${item.priorityRank}` : item.priorityRank}
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="text-xs font-mono font-bold uppercase text-sky-400">
                          Priority {item.priorityRank}
                        </span>
                        <SeverityBadge severity={item.severity} size="xs" />
                        <ObservabilityPill status={item.observability} size="xs" />
                      </div>
                      <h3 className="text-sm font-bold text-white">
                        {item.title}
                      </h3>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center">
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-mono text-gray-500 block">
                        Rank Score
                      </span>
                      <span className="text-sm font-mono font-bold text-sky-400">
                        {score} pts
                      </span>
                    </div>

                    <button
                      onClick={() => toggleFormula(item.id)}
                      className="text-xs font-mono text-gray-400 hover:text-white px-2.5 py-1.5 rounded bg-[#111827] border border-[#1F2937] flex items-center gap-1.5 transition-colors"
                      title="Inspect formula breakdown"
                    >
                      <Calculator className="w-3.5 h-3.5" />
                      <span>{isFormulaExpanded ? 'Hide' : 'Inspect'}</span>
                    </button>
                  </div>
                </div>

                {/* Risk & Impact */}
                <div className="space-y-2">
                  <div className="text-xs text-gray-300 leading-relaxed">
                    <strong className="text-gray-200">Risk Assessment: </strong>
                    {item.whyDangerous}
                  </div>

                  {item.impact && item.impact.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <span className="text-[11px] font-mono text-gray-500 mr-1">Impact Vector:</span>
                      {item.impact.map((tag, i) => (
                        <span 
                          key={i}
                          className="px-2 py-0.5 rounded bg-red-950/30 border border-red-800/40 text-red-300 text-[10px] font-mono flex items-center gap-1"
                        >
                          <Tag className="w-2.5 h-2.5" />
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Recommended Remediation Action Box */}
                <div className="p-3.5 rounded-lg bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                      <Wrench className="w-3.5 h-3.5" />
                      Recommended Remediation Action
                    </span>
                    <button
                      onClick={() => handleCopy(item.id, item.recommendedFix)}
                      className="text-[11px] font-mono px-2.5 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 flex items-center gap-1 transition-colors"
                    >
                      {copiedId === item.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedId === item.id ? 'Copied' : 'Copy Remediation'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-gray-200 leading-relaxed font-mono">
                    {item.recommendedFix}
                  </p>
                </div>

                {/* Formula Breakdown Details Drawer */}
                {isFormulaExpanded && b && (
                  <div className="p-3.5 rounded-lg bg-[#0B0F14] border border-[#1F2937] space-y-2 font-mono text-xs">
                    <div className="flex items-center justify-between text-gray-400 text-[11px] pb-1 border-b border-[#1F2937]">
                      <span className="text-sky-300 font-semibold">Priority Ranking Parameter Verification</span>
                      <span>Target: {item.id}</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1 text-[11px]">
                      <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                        <span className="text-gray-500 block text-[10px]">Severity (Weight ×4)</span>
                        <span className="text-white font-bold text-sm">{b.severity} / 10</span>
                        <span className="text-[10px] text-gray-400 block">+{(b.severity * 4)} pts</span>
                      </div>

                      <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                        <span className="text-gray-500 block text-[10px]">Exploitability (Weight ×3)</span>
                        <span className="text-white font-bold text-sm">{b.exploitability} / 10</span>
                        <span className="text-[10px] text-gray-400 block">+{(b.exploitability * 3)} pts</span>
                      </div>

                      <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                        <span className="text-gray-500 block text-[10px]">Exposure (Weight ×3)</span>
                        <span className="text-white font-bold text-sm">{b.exposure} / 10</span>
                        <span className="text-[10px] text-gray-400 block">+{(b.exposure * 3)} pts</span>
                      </div>

                      <div className="p-2 rounded bg-[#161B22] border border-[#1F2937]">
                        <span className="text-gray-500 block text-[10px]">Deprecated Alg Factor</span>
                        <span className="text-white font-bold text-sm">{b.deprecated ? 'YES (+15)' : 'NO (0)'}</span>
                        <span className="text-[10px] text-gray-400 block">{b.deprecated ? '+15 pts' : '0 pts'}</span>
                      </div>
                    </div>

                    <div className="text-[11px] text-gray-400 pt-1 flex items-center justify-between">
                      <span>Total Priority Rank Score: <strong className="text-sky-400">{score} points</strong></span>
                      <span className="text-emerald-400">Impacts: {b.cia?.join(', ') || 'General'}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="bg-[#161B22] border border-[#1F2937] rounded-xl p-8 text-center text-gray-400">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm font-mono text-gray-200">No high-priority vulnerabilities identified in this scenario.</p>
            <p className="text-xs text-gray-500 mt-1">Active configuration fulfills modern baseline cryptographic standards.</p>
          </div>
        )}
      </div>
    </div>
  );
}
