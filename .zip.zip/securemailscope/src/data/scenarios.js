/**
 * SecureMailScope — Mock Scenarios Data
 * 
 * Deterministic Risk Scoring Formula:
 * -----------------------------------
 * Posture scores are calculated on a scale of 0 to 100 where 100 represents an optimal,
 * modern, and uncompromised cryptographic posture, and 0 represents complete vulnerability.
 *
 * Base Score = 100.
 * Findings deduct points based on calculated finding penalty weights:
 * - Critical finding penalty: -22 to -28 points (depending on exploitability & exposure)
 * - High finding penalty: -12 to -16 points
 * - Medium finding penalty: -6 to -9 points
 * - Low finding penalty: -2 to -4 points
 * - Info: 0 points
 * 
 * Dimension breakdown scores:
 * - tlsSecurity: Weighted evaluation of TLS protocol version & downgrade protection.
 * - algorithmStrength: Symmetric cipher security (AEAD vs CBC vs Stream) & PRF hash function.
 * - keySecurity: Ephemeral Diffie-Hellman parameters (Curve25519/ECDHE vs static RSA).
 * - certificateSecurity: Public key length (e.g. 2048+ vs 1024) and signature hash (SHA-256 vs SHA-1).
 * - emailEncryption: S/MIME, PGP, or transport-enforced STARTTLS posture.
 * 
 * IMPORTANT: When a dimension cannot be observed due to protocol opacity (such as TLS 1.3
 * encrypting certificates and payload), its score is marked `null` ("Not scored - not observable")
 * and is explicitly omitted from penalty calculations, preventing artificial penalties for proper opacity.
 */

export const SCENARIOS = [
  {
    id: "scenario_a",
    name: "Scenario A — Modern Baseline",
    badgeLabel: "Modern Baseline",
    description: "TLS 1.3 email session against a corporate mail gateway with robust forward secrecy and AEAD cipher.",
    uploadedFile: {
      name: "scenario_a_secure_email.pcap",
      sizeKB: 842,
      packetCount: 6210,
      durationSec: 41,
      protocolsDetected: ["TCP", "TLS 1.3", "SMTP (STARTTLS)", "DNS"]
    },
    trafficOverview: {
      totalPackets: 6210,
      emailSessions: 12,
      tlsSessions: 12,
      unencryptedSessions: 0,
      clientIPs: ["192.168.10.45", "192.168.10.48", "192.168.10.52"],
      serverIPs: ["203.0.113.25 (mail.corp-secure.org)"],
      starttlsNegotiated: 12,
      plaintextFallbacks: 0
    },
    cryptoDiscovery: {
      tlsVersion: {
        label: "TLS Protocol Version",
        value: "TLS 1.3 (0x0304)",
        observability: "observed",
        note: "Negotiated via supported_versions extension in ServerHello"
      },
      cipherSuite: {
        label: "Cipher Suite",
        value: "TLS_AES_256_GCM_SHA384 (0x1302)",
        observability: "observed",
        note: "Authenticated Encryption with Associated Data (AEAD) standard"
      },
      keyExchange: {
        label: "Key Exchange Mechanism",
        value: "X25519 (ECDHE, 253-bit Curve25519)",
        observability: "observed",
        note: "Provides Perfect Forward Secrecy (PFS); ephemeral key share in Client/ServerHello"
      },
      certificate: {
        keyType: {
          label: "Certificate Public Key Type",
          value: null,
          observability: "not_observable",
          note: "TLS 1.3 encrypts the Certificate message after ServerHello. Payload opaque to passive PCAP."
        },
        keySize: {
          label: "Certificate Key Length",
          value: null,
          observability: "not_observable",
          note: "Encrypted within TLS 1.3 handshake frames"
        },
        sigAlg: {
          label: "Certificate Signature Algorithm",
          value: null,
          observability: "not_observable",
          note: "Encrypted within TLS 1.3 handshake frames"
        },
        sanDomains: {
          label: "Subject Alternative Names (SAN)",
          value: null,
          observability: "not_observable",
          note: "Encrypted in certificate payload"
        }
      },
      signatureAlgOffered: {
        label: "Signature Schemes Offered",
        value: "ecdsa_secp256r1_sha256, rsa_pss_rsae_sha256, rsa_pkcs1_sha256",
        observability: "observed",
        note: "Client-offered list extracted from ClientHello extension (advertised, not necessarily selected)"
      },
      smime: {
        label: "S/MIME End-to-End Encryption",
        value: null,
        observability: "not_observable",
        note: "Email body and MIME parts are fully encrypted inside the TLS 1.3 session"
      },
      pgp: {
        label: "OpenPGP Body Signatures",
        value: null,
        observability: "not_observable",
        note: "Transport payload is opaque; PGP armor headers cannot be inspected passively"
      },
      hashDeprecatedFound: {
        label: "Deprecated Hash Detected (MD5 / SHA-1)",
        value: false,
        observability: "observed",
        note: "No legacy hash identifiers observed in negotiated extensions or cipher specs"
      },
      pfsEnabled: {
        label: "Perfect Forward Secrecy (PFS)",
        value: "Enforced (ECDHE / X25519)",
        observability: "inferred",
        note: "Derived from mandatory ephemeral key agreement in TLS 1.3 specification"
      }
    },
    findings: [
      {
        id: "f_a1",
        title: "Legacy RSA PKCS#1 v1.5 Signature Scheme Advertised in ClientHello",
        severity: "info",
        category: "authentication",
        observability: "observed",
        detected: "ClientHello advertised rsa_pkcs1_sha256 in signature_algorithms extension",
        whyDangerous: "While not negotiated in this session, offering RSA PKCS#1 v1.5 allows potential downgrade or Bleichenbacher-style oracle attacks if connected to legacy misconfigured peers.",
        impact: ["Theoretical downgrade risk with legacy endpoints", "Sub-optimal client hygiene"],
        priorityRank: 1,
        priorityScoreBreakdown: {
          severity: 1,
          exploitability: 2,
          exposure: 2,
          deprecated: false,
          cia: ["Authentication"]
        },
        recommendedFix: "Restrict client signature_algorithms extension to RSA-PSS (e.g. rsa_pss_rsae_sha256) and ECDSA schemes.",
        aiNarrative: "The client advertises legacy PKCS#1 v1.5 schemes in its signature_algorithms extension list alongside modern PSS and ECDSA. The server correctly selected TLS 1.3 with modern crypto, making this an informational observation regarding client-side posture rather than an active exploit path."
      }
    ],
    riskScore: {
      overall: 91,
      band: "LOW RISK",
      statusColor: "#16A34A",
      breakdown: {
        tlsSecurity: 96,
        algorithmStrength: 92,
        keySecurity: 95,
        certificateSecurity: null, // TLS 1.3 encrypted cert -> not observable
        emailEncryption: null      // TLS 1.3 encrypted body -> not observable
      }
    },
    aiSummary: "The captured email session negotiated TLS 1.3 with AES-256-GCM and X25519 key exchange, representing current best-practice transport security. Certificate details (key size, signature algorithm) and email-body-level indicators (S/MIME, PGP) could not be observed from passive PCAP inspection because TLS 1.3 encrypts all handshake messages subsequent to ServerHello by design. This opacity is a fundamental cryptographic privacy property, not an assessment failure. Posture is rated Low Risk (Score: 91/100)."
  },

  {
    id: "scenario_b",
    name: "Scenario B — Mixed Configuration",
    badgeLabel: "Mixed Configuration",
    description: "TLS 1.2 email session with cleartext certificate, SHA-1 certificate signature, and unencrypted SMTP fallback sessions.",
    uploadedFile: {
      name: "scenario_b_mixed_gateway.pcap",
      sizeKB: 1420,
      packetCount: 11450,
      durationSec: 88,
      protocolsDetected: ["TCP", "TLS 1.2", "SMTP (STARTTLS)", "SMTP (Plaintext)", "DNS"]
    },
    trafficOverview: {
      totalPackets: 11450,
      emailSessions: 37,
      tlsSessions: 31,
      unencryptedSessions: 6,
      clientIPs: ["10.0.4.12", "10.0.4.19", "10.0.5.88", "192.168.1.104"],
      serverIPs: ["198.51.100.14 (relay.enterprise-mail.net)"],
      starttlsNegotiated: 31,
      plaintextFallbacks: 6
    },
    cryptoDiscovery: {
      tlsVersion: {
        label: "TLS Protocol Version",
        value: "TLS 1.2 (0x0303)",
        observability: "observed",
        note: "Observed in ServerHello version field"
      },
      cipherSuite: {
        label: "Cipher Suite",
        value: "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 (0xC027)",
        observability: "observed",
        note: "Uses CBC (Cipher Block Chaining) mode; vulnerable to timing and padding oracle attacks"
      },
      keyExchange: {
        label: "Key Exchange Mechanism",
        value: "ECDHE (secp256r1 / NIST P-256)",
        observability: "observed",
        note: "Provides forward secrecy, but combined with legacy CBC symmetric encryption"
      },
      certificate: {
        keyType: {
          label: "Certificate Public Key Type",
          value: "RSA",
          observability: "observed",
          note: "Extracted from cleartext Certificate handshake message in TLS 1.2"
        },
        keySize: {
          label: "Certificate Key Length",
          value: "2048-bit",
          observability: "observed",
          note: "Adequate key length per NIST SP 800-57, but undermined by signature hash"
        },
        sigAlg: {
          label: "Certificate Signature Algorithm",
          value: "SHA1withRSA (1.2.840.113549.1.1.5)",
          observability: "observed",
          note: "CRITICAL: SHA-1 is cryptographically broken due to collision vulnerabilities"
        },
        sanDomains: {
          label: "Subject Alternative Names (SAN)",
          value: "relay.enterprise-mail.net, autodiscover.enterprise-mail.net",
          observability: "observed",
          note: "Extracted from X.509 v3 extension list"
        }
      },
      signatureAlgOffered: {
        label: "Signature Schemes Offered",
        value: "rsa_pkcs1_sha1, rsa_pkcs1_sha256, ecdsa_secp256r1_sha256",
        observability: "observed",
        note: "Client and server agreed on legacy SHA-1 verification path"
      },
      smime: {
        label: "S/MIME End-to-End Encryption",
        value: "Observed in 6 plaintext SMTP sessions",
        observability: "observed",
        note: "S/MIME multipart/signed MIME boundary detected directly in unencrypted SMTP traffic"
      },
      pgp: {
        label: "OpenPGP Body Signatures",
        value: "Not detected",
        observability: "observed",
        note: "No PGP ASCII armor headers observed in examined plaintext streams"
      },
      hashDeprecatedFound: {
        label: "Deprecated Hash Detected (MD5 / SHA-1)",
        value: true,
        observability: "observed",
        note: "SHA-1 identified in active X.509 server certificate signature"
      },
      pfsEnabled: {
        label: "Perfect Forward Secrecy (PFS)",
        value: "Present (ECDHE)",
        observability: "inferred",
        note: "ECDHE key exchange provides session PFS despite cipher and cert weaknesses"
      }
    },
    findings: [
      {
        id: "f_b1",
        title: "SHA-1 Certificate Signature Algorithm in Production Mail Server",
        severity: "critical",
        category: "integrity",
        observability: "observed",
        detected: "X.509 server certificate signed with SHA1withRSA (OID: 1.2.840.113549.1.1.5)",
        whyDangerous: "SHA-1 has demonstrated practical collision attacks (SHAttered attack). Threat actors with moderate cloud compute can generate fraudulent rogue certificates sharing identical signatures, completely defeating server authenticity and enabling silent Man-in-the-Middle (MitM) interception.",
        impact: ["Certificate forgery via hash collisions", "Man-in-the-Middle interception", "Loss of mail authenticity"],
        priorityRank: 1,
        priorityScoreBreakdown: {
          severity: 9,
          exploitability: 7,
          exposure: 9,
          deprecated: true,
          cia: ["Integrity", "Authentication"]
        },
        recommendedFix: "Immediately revoke and reissue the TLS certificate using SHA-256 or SHA-384 with RSA 2048+ or ECDSA P-256. Ensure root/intermediate CA chains do not include SHA-1 signatures.",
        aiNarrative: "The mail gateway presents an RSA-2048 certificate that is signed using the obsolete SHA-1 hash algorithm. While 2048 bits provides adequate factorization hardness, the SHA-1 signature undermines the entire chain of trust. Browsers and modern MTA-STS validators reject SHA-1 certificates, causing delivery dropouts and high MitM vulnerability."
      },
      {
        id: "f_b2",
        title: "Unencrypted SMTP Plaintext Sessions Allowed (STARTTLS Not Enforced)",
        severity: "high",
        category: "confidentiality",
        observability: "observed",
        detected: "6 of 37 email sessions transmitted in cleartext on TCP port 25 without STARTTLS negotiation",
        whyDangerous: "Lack of mandatory TLS enforcement allows network eavesdroppers to harvest email credentials, recipient routing data, subject headers, and unencrypted message bodies via passive wiretapping.",
        impact: ["Cleartext email eavesdropping", "Credential harvesting", "Metadata leakage"],
        priorityRank: 2,
        priorityScoreBreakdown: {
          severity: 8,
          exploitability: 9,
          exposure: 8,
          deprecated: false,
          cia: ["Confidentiality"]
        },
        recommendedFix: "Configure mail transfer agent (MTA) with 'smtpd_tls_security_level = encrypt' (Postfix) or equivalent to reject unencrypted inbound/outbound transmissions. Implement MTA-STS and DANE TLSA records.",
        aiNarrative: "Six sessions failed to negotiate STARTTLS and proceeded in pure plaintext ASCII. While the remaining 31 sessions used TLS 1.2, opportunistic encryption without mandatory enforcement fails to protect against active STRIPTLS downgrade attacks."
      },
      {
        id: "f_b3",
        title: "CBC-Mode Cipher Suite In Use Under TLS 1.2",
        severity: "medium",
        category: "confidentiality",
        observability: "observed",
        detected: "Cipher suite TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 selected",
        whyDangerous: "Cipher Block Chaining (CBC) mode with HMAC in TLS 1.2 is vulnerable to side-channel timing attacks (Lucky13, POODLE-variant) due to MAC-then-Encrypt construction flaw, allowing iterative plaintext recovery.",
        impact: ["Side-channel plaintext recovery", "Cryptographic timing leak"],
        priorityRank: 3,
        priorityScoreBreakdown: {
          severity: 6,
          exploitability: 4,
          exposure: 7,
          deprecated: false,
          cia: ["Confidentiality"]
        },
        recommendedFix: "Prioritize AEAD ciphers in mail gateway configuration: ECDHE-ECDSA-AES128-GCM-SHA256, ECDHE-RSA-AES128-GCM-SHA256, or CHACHA20-POLY1305. Deprecate CBC ciphers in server cipher preference.",
        aiNarrative: "The cipher suite uses AES-128 in CBC mode. Modern security baselines mandate AEAD (such as GCM or ChaCha20-Poly1305) which couples encryption and integrity verification simultaneously, neutralizing MAC-then-Encrypt timing attacks."
      },
      {
        id: "f_b4",
        title: "S/MIME Envelope Metadata Observable in Cleartext Traffic",
        severity: "low",
        category: "confidentiality",
        observability: "observed",
        detected: "MIME header 'Content-Type: multipart/signed; protocol=\"application/pkcs7-signature\"' found in plaintext SMTP stream",
        whyDangerous: "Although message payload content remained signed, transmitting S/MIME structures over unencrypted SMTP exposes sender certs, algorithm parameters, and sender/receiver relational metadata to network observers.",
        impact: ["Communication profiling", "Metadata exposure"],
        priorityRank: 4,
        priorityScoreBreakdown: {
          severity: 3,
          exploitability: 8,
          exposure: 5,
          deprecated: false,
          cia: ["Confidentiality"]
        },
        recommendedFix: "Enforce transport-layer TLS encryption so that S/MIME wrappers and message headers are never exposed across intermediate internet transit hops.",
        aiNarrative: "In the 6 unencrypted sessions, S/MIME signatures were directly parsed from the packet stream. This demonstrates the critical nuance that S/MIME protects payload integrity, but without underlying transport encryption (TLS), metadata and protocol structures remain fully visible."
      }
    ],
    riskScore: {
      overall: 62,
      band: "MEDIUM RISK",
      statusColor: "#D97706",
      breakdown: {
        tlsSecurity: 68,
        algorithmStrength: 64,
        keySecurity: 78,
        certificateSecurity: 38, // heavily degraded by SHA-1
        emailEncryption: 62
      }
    },
    aiSummary: "The assessment identified a critical vulnerability in the mail server's certificate infrastructure: the server presents an RSA-2048 certificate signed with deprecated SHA-1, leaving it vulnerable to forgery attacks. Furthermore, 6 email sessions transmitted in cleartext without STARTTLS enforcement, exposing message headers and S/MIME structural metadata. While ECDHE key exchange was negotiated for encrypted sessions, the use of CBC-mode cipher suites introduces padding oracle risk. Posture is rated Medium Risk (Score: 62/100). Prioritized remediation is required for certificate reissue and STARTTLS enforcement."
  },

  {
    id: "scenario_c",
    name: "Scenario C — Legacy / Weak",
    badgeLabel: "Legacy / Weak",
    description: "Severely compromised TLS 1.0 email infrastructure using static RSA key exchange, RC4 stream cipher, and 1024-bit SHA-1 certificate.",
    uploadedFile: {
      name: "scenario_c_legacy_infrastructure.pcap",
      sizeKB: 2150,
      packetCount: 16820,
      durationSec: 142,
      protocolsDetected: ["TCP", "TLS 1.0", "SMTP (STARTTLS)", "SMTP (Plaintext)", "DNS"]
    },
    trafficOverview: {
      totalPackets: 16820,
      emailSessions: 18,
      tlsSessions: 14,
      unencryptedSessions: 4,
      clientIPs: ["172.16.20.11", "172.16.20.15", "172.16.21.90"],
      serverIPs: ["192.0.2.77 (mail-legacy.internal.agency.gov)"],
      starttlsNegotiated: 14,
      plaintextFallbacks: 4
    },
    cryptoDiscovery: {
      tlsVersion: {
        label: "TLS Protocol Version",
        value: "TLS 1.0 (0x0301)",
        observability: "observed",
        note: "CRITICAL: Formally deprecated under RFC 8996; lacks modern PRF and AEAD primitives"
      },
      cipherSuite: {
        label: "Cipher Suite",
        value: "TLS_RSA_WITH_RC4_128_SHA (0x0005)",
        observability: "observed",
        note: "CRITICAL: Prohibited by RFC 7465 due to severe keystream biases (Bar Mitzvah / Royal Holloway attacks)"
      },
      keyExchange: {
        label: "Key Exchange Mechanism",
        value: "Static RSA Key Exchange (No PFS)",
        observability: "observed",
        note: "Pre-master secret encrypted with server public key. Compromise of server private key decrypts ALL historical sessions."
      },
      certificate: {
        keyType: {
          label: "Certificate Public Key Type",
          value: "RSA",
          observability: "observed",
          note: "Cleartext transmission in TLS 1.0 handshake"
        },
        keySize: {
          label: "Certificate Key Length",
          value: "1024-bit",
          observability: "observed",
          note: "CRITICAL: Inadequate key length. 1024-bit RSA is breakable by state-level actors; disallowed by NIST since 2013."
        },
        sigAlg: {
          label: "Certificate Signature Algorithm",
          value: "SHA1withRSA (1.2.840.113549.1.1.5)",
          observability: "observed",
          note: "Depreciated SHA-1 digest vulnerable to practical collisions"
        },
        sanDomains: {
          label: "Subject Alternative Names (SAN)",
          value: "mail-legacy.internal.agency.gov",
          observability: "observed",
          note: "Extracted from cleartext certificate payload"
        }
      },
      signatureAlgOffered: {
        label: "Signature Schemes Offered",
        value: "Not specified (TLS 1.0 uses hardcoded MD5/SHA-1 dual PRF)",
        observability: "inferred",
        note: "TLS 1.0 lacks signature_algorithms extension, defaulting to MD5+SHA1 internal combinations"
      },
      smime: {
        label: "S/MIME End-to-End Encryption",
        value: "None detected",
        observability: "observed",
        note: "Plaintext sessions contain unencrypted raw MIME parts; no PKCS#7 or CMS structures"
      },
      pgp: {
        label: "OpenPGP Body Signatures",
        value: "None detected",
        observability: "observed",
        note: "No OpenPGP packets found in payload inspection"
      },
      hashDeprecatedFound: {
        label: "Deprecated Hash Detected (MD5 / SHA-1)",
        value: true,
        observability: "observed",
        note: "Both SHA-1 and MD5 dependencies detected in TLS 1.0 PRF and certificate"
      },
      pfsEnabled: {
        label: "Perfect Forward Secrecy (PFS)",
        value: "ABSENT — Static RSA",
        observability: "observed",
        note: "No ephemeral DH/ECDH exchange. Total lack of forward secrecy."
      }
    },
    findings: [
      {
        id: "f_c1",
        title: "No Perfect Forward Secrecy (Static RSA Key Exchange)",
        severity: "critical",
        category: "confidentiality",
        observability: "observed",
        detected: "Cipher suite TLS_RSA_WITH_RC4_128_SHA uses static RSA key exchange without Diffie-Hellman",
        whyDangerous: "The pre-master secret is encrypted directly with the server's long-term RSA public key. Any adversary who records network traffic today can retroactively decrypt all recorded email conversations in the future if they ever obtain the server's private key (via breach, warrant, or decommissioned hardware).",
        impact: ["Retroactive bulk decryption of all captured email", "Total loss of long-term confidentiality"],
        priorityRank: 1,
        priorityScoreBreakdown: {
          severity: 10,
          exploitability: 8,
          exposure: 10,
          deprecated: true,
          cia: ["Confidentiality"]
        },
        recommendedFix: "Disable all static RSA key exchange suites. Mandate ephemeral Diffie-Hellman (ECDHE with X25519 or secp256r1/secp384r1) to guarantee session-unique forward secrecy.",
        aiNarrative: "Static RSA key exchange represents a catastrophic risk to organizational confidentiality. Unlike modern forward-secret exchanges where ephemeral session keys are discarded immediately, every historical session in this capture can be retroactively unwrapped if the RSA private key is ever exposed."
      },
      {
        id: "f_c2",
        title: "Prohibited RC4 Stream Cipher In Active Negotiation",
        severity: "critical",
        category: "confidentiality",
        observability: "observed",
        detected: "Negotiated cipher TLS_RSA_WITH_RC4_128_SHA uses the RC4 stream algorithm (RFC 7465 violation)",
        whyDangerous: "RC4 suffers from severe statistical keystream biases in the initial output bytes. Practical attacks (Bar Mitzvah, Royal Holloway plaintext recovery) allow passive adversaries to reconstruct sensitive session cookies, authentication tokens, and email headers by monitoring multiple connections.",
        impact: ["Keystream bias plaintext recovery", "Session token and password theft", "Compliance failure (PCI-DSS / NIST)"],
        priorityRank: 2,
        priorityScoreBreakdown: {
          severity: 10,
          exploitability: 8,
          exposure: 9,
          deprecated: true,
          cia: ["Confidentiality", "Integrity"]
        },
        recommendedFix: "Completely disable RC4 ciphers in mail gateway configuration. Replace with modern AES-GCM or ChaCha20-Poly1305 ciphers.",
        aiNarrative: "RC4 is formally banned across all internet standards (RFC 7465). Keystream biases allow plaintext extraction without requiring private key compromise, making its presence in mail transit an acute emergency."
      },
      {
        id: "f_c3",
        title: "Obsolete TLS 1.0 Protocol Version Active",
        severity: "critical",
        category: "integrity",
        observability: "observed",
        detected: "Negotiated protocol TLS 1.0 (0x0301) on mail port",
        whyDangerous: "TLS 1.0 was officially deprecated by RFC 8996. It relies on MD5/SHA-1 internal hashes, is vulnerable to BEAST and downgrade attacks, and lacks modern authenticated encryption (AEAD) primitives.",
        impact: ["BEAST protocol vulnerability", "Lack of AEAD protection", "Regulatory non-compliance"],
        priorityRank: 3,
        priorityScoreBreakdown: {
          severity: 9,
          exploitability: 7,
          exposure: 9,
          deprecated: true,
          cia: ["Integrity", "Confidentiality"]
        },
        recommendedFix: "Upgrade MTA to support TLS 1.3 as primary, with TLS 1.2 as minimum fallback. Completely disable TLS 1.0 and TLS 1.1.",
        aiNarrative: "The mail gateway continues to negotiate TLS 1.0. Modern mail services and secure relays actively refuse connection attempts from TLS 1.0 endpoints, degrading deliverability and creating a broad target for automated scanner exploits."
      },
      {
        id: "f_c4",
        title: "Inadequate 1024-bit RSA Certificate Key Length",
        severity: "high",
        category: "authentication",
        observability: "observed",
        detected: "Server X.509 certificate public key modulus is only 1024 bits (RSA 1024)",
        whyDangerous: "1024-bit RSA keys provide less than 80 bits of symmetric security equivalence. Advances in general number field sieve (GNFS) algorithms place 1024-bit factorization within reach of nation-state actors and large botnets. Deprecated by NIST since 2013.",
        impact: ["Key factorization exposure", "Server impersonation", "Rogue certificate issuance"],
        priorityRank: 4,
        priorityScoreBreakdown: {
          severity: 8,
          exploitability: 5,
          exposure: 8,
          deprecated: true,
          cia: ["Authentication"]
        },
        recommendedFix: "Replace the 1024-bit certificate with a 2048-bit or 4096-bit RSA certificate, or preferably an ECDSA P-256 certificate.",
        aiNarrative: "The 1024-bit RSA certificate modulus falls far below contemporary cryptographic thresholds (minimum 2048-bit required). Factoring this modulus reveals the server's private key, immediately compounding the Static RSA finding (f_c1)."
      },
      {
        id: "f_c5",
        title: "Deprecated SHA-1 Signature in Certificate Chain",
        severity: "critical",
        category: "integrity",
        observability: "observed",
        detected: "Server certificate signed with SHA1withRSA",
        whyDangerous: "SHA-1 collision attacks allow creation of rogue certificates that validate against identical signatures.",
        impact: ["Certificate forgery", "Man-in-the-Middle spoofing"],
        priorityRank: 5,
        priorityScoreBreakdown: {
          severity: 9,
          exploitability: 7,
          exposure: 8,
          deprecated: true,
          cia: ["Integrity", "Authentication"]
        },
        recommendedFix: "Reissue certificate signed by a CA utilizing SHA-256 or SHA-384.",
        aiNarrative: "The legacy certificate relies on SHA-1 signatures. Combined with the 1024-bit key, the identity layer of this email server provides virtually no cryptographic guarantees against active adversaries."
      },
      {
        id: "f_c6",
        title: "Plaintext SMTP Unencrypted Traffic Permitted",
        severity: "medium",
        category: "confidentiality",
        observability: "observed",
        detected: "4 sessions conducted in cleartext SMTP without STARTTLS initiation",
        whyDangerous: "Unencrypted email transmission permits sniffing of communications and credentials on intermediate routers.",
        impact: ["Eavesdropping", "Metadata exposure"],
        priorityRank: 6,
        priorityScoreBreakdown: {
          severity: 7,
          exploitability: 9,
          exposure: 6,
          deprecated: false,
          cia: ["Confidentiality"]
        },
        recommendedFix: "Enforce STARTTLS strictly and reject unencrypted SMTP transactions.",
        aiNarrative: "Four sessions proceeded entirely in cleartext. In an environment already compromised by legacy TLS 1.0, the presence of raw cleartext transmission leaves zero defense-in-depth."
      }
    ],
    riskScore: {
      overall: 24,
      band: "CRITICAL RISK",
      statusColor: "#DC2626",
      breakdown: {
        tlsSecurity: 15,
        algorithmStrength: 18,
        keySecurity: 20,
        certificateSecurity: 22,
        emailEncryption: 35
      }
    },
    aiSummary: "CRITICAL RISK DETECTED: The mail infrastructure represents a textbook legacy configuration that violates nearly every modern cryptographic guideline. It negotiates TLS 1.0 using static RSA key exchange (no forward secrecy) and the banned RC4 stream cipher. Furthermore, the X.509 certificate relies on an insecure 1024-bit RSA key and a deprecated SHA-1 signature. An adversary with passive wiretap access can store and decrypt all historical sessions, while active attackers can forge certificates or extract plaintexts via RC4 keystream biases. Immediate server decommission or comprehensive TLS stack modernization is urgently required."
  }
];

export const PIPELINE_STAGES = [
  { id: 1, title: "Loading PCAP", desc: "Ingesting raw packet capture frames into memory buffer" },
  { id: 2, title: "Parsing Packets", desc: "Dissecting Ethernet, IPv4/IPv6, and TCP transport layers" },
  { id: 3, title: "Identifying Email Traffic", desc: "Isolating SMTP (port 25/587/465), IMAP (143/993), POP3 (110/995)" },
  { id: 4, title: "Extracting TLS Info", desc: "Analyzing ClientHello, ServerHello, extensions, and protocol versions" },
  { id: 5, title: "Identifying Certificates", desc: "Inspecting X.509 cert chains, key lengths, validity, and CA signatures" },
  { id: 6, title: "Analyzing Crypto Algorithms", desc: "Evaluating symmetric ciphers, MAC/AEAD modes, and PRF hash functions" },
  { id: 7, title: "Extracting Key Parameters", desc: "Assessing DH/ECDHE curves, forward secrecy (PFS), and modulus strength" },
  { id: 8, title: "Checking S/MIME & PGP", desc: "Inspecting message MIME parts for PKCS#7 signatures or PGP armor" },
  { id: 9, title: "Preparing Feature Vectors", desc: "Vectorizing cryptographic posture parameters for heuristic risk engine" },
  { id: 10, title: "Generating Risk Assessment", desc: "Synthesizing scores, CIA triad impact analysis, and remediation priority" }
];
