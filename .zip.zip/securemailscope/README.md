# SecureMailScope — Intelligent Cryptographic Posture Assessment

> *"Discover. Assess. Analyze. Prioritize. Remediate."*  
> Turning raw email-network traffic into an understandable cryptographic security posture.

Built for the **Smart India Hackathon (SIH)**, **SecureMailScope** is a SOC-grade frontend analysis engine that models and assesses the cryptographic health of enterprise Mail Transfer Agents (MTAs). Operating on network packet captures (PCAP/PCAPNG), it extracts TLS handshakes, certificate chains, and payload encryption indicators without guessing or fabricating unobservable data.

---

## 🛡️ Core Highlights & Ground-Truth Credibility

### 1. Three-Tier Observability Guarantee
Judges scrutinize technical accuracy. SecureMailScope enforces strict cryptographic observability:
- 🟢 **Observed**: Directly dissected from packet frames (e.g. ClientHello, ServerHello, cleartext headers).
- 🟡 **Inferred**: Derived deterministically from observed parameters (e.g. RFC-defined cipher properties, PFS).
- ⚪ **Not Observable from PCAP**: Explicitly encrypted or withheld by protocol design (e.g. TLS 1.3 encrypted certificates, S/MIME within TLS). Rendered in gray, never left blank, and never guessed.

### 2. Three Realistic Evaluation Scenarios
- **Scenario A — Modern Baseline (Score: 91, LOW RISK)**:
  - TLS 1.3 (`TLS_AES_256_GCM_SHA384`) with X25519 forward secrecy.
  - Demonstrates the vital nuance that **secure means properly opaque**: certificates and email payloads are encrypted by TLS 1.3 by design, so certificate and S/MIME fields are correctly tagged as *Not Observable from PCAP*.
- **Scenario B — Mixed Configuration (Score: 62, MEDIUM RISK)**:
  - TLS 1.2 with RSA-2048 certificate, but critically undermined by a **SHA-1 signature algorithm**.
  - 31 TLS sessions and 6 plaintext SMTP sessions (STARTTLS not enforced). Demonstrates that **S/MIME is observable only in unencrypted sessions**.
- **Scenario C — Legacy / Weak (Score: 24, CRITICAL RISK)**:
  - TLS 1.0 with static RSA key exchange (No Perfect Forward Secrecy) and banned RC4-128 stream cipher.
  - 1024-bit RSA certificate key length and SHA-1 signature. Three distinct, correctly labeled vulnerabilities.

---

## 🚀 Navigation & Platform Views

1. **Dashboard**: Executive posture overview with animated radial RiskGauge, 5-metric dimensional breakdown bars (with null-handling), severity stat cards, and mini 10-stage pipeline overview.
2. **PCAP Analyzer**: Simulated file ingestion dropzone with metadata preview card and animated 10-stage dissection pipeline with live real-time console ticker and auto-navigation to Discovery.
3. **Discovery**: Structured cryptographic telemetry ledger covering TLS versions, ciphers, key exchange, X.509 certificates, SAN domains, and S/MIME indicators, complete with observability pills and technical RFC notes.
4. **AI Analysis**: Distinct AI reasoning block synthesizing the overall security posture, CIA triad impact analysis, and cross-layer compounding attack paths.
5. **Risk Assessment**: Deep vulnerability ledger with filterable findings by severity and CIA security pillar, expandable cards, and potential impact tags.
6. **Prioritized Fixes**: Ordered remediation backlog ranked via transparent mathematical formula:  
   $$\text{Rank Score} = (\text{Severity} \times 4) + (\text{Exploitability} \times 3) + (\text{Exposure} \times 3) + (\text{Deprecated} ? 15 : 0)$$  
   with expandable parameter inspection drawer.
7. **Recommendations**: Severity-grouped action items (🔴 Critical, 🟠 High, 🟡 Medium, 🟢 Low) with interactive remediation checkboxes and ready-to-deploy MTA hardening snippets for Postfix and Nginx.
8. **Report**: Formal audit report formatted for compliance and CISO briefings, complete with one-click `window.print()` PDF generation.

---

## 💻 Tech Stack

- **Framework**: React 19 + Vite 5
- **Styling**: Tailwind CSS (SOC Dark Aesthetic: `#0B0F14` base, `#161B22` panels, `#38BDF8` cyan accents)
- **Icons**: Lucide React
- **Typography**: Inter (UI) + JetBrains Mono (Technical data & cryptographic values)

---

## 🛠️ Getting Started Locally

```bash
# Clone or navigate to the repository
cd securemailscope

# Install dependencies
npm install

# Start the Vite development server
npm run dev

# Open http://localhost:3000 in your browser
```

To create an optimized production build:
```bash
npm run build
npm run preview
```
