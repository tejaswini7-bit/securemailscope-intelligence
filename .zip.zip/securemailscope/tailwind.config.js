/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        soc: {
          bg: '#0B0F14',
          surface: '#111827',
          panel: '#161B22',
          border: '#1F2937',
          borderLight: '#374151',
          accent: '#38BDF8',
          accentBlue: '#3B82F6',
          muted: '#9CA3AF',
          text: '#F3F4F6',
        },
        severity: {
          critical: '#DC2626',
          high: '#EA580C',
          medium: '#D97706',
          low: '#16A34A',
          info: '#6B7280',
        },
        observability: {
          observed: '#10B981',
          inferred: '#F59E0B',
          notObservable: '#6B7280',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'IBM Plex Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
